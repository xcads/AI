﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using ZierbensTetris.DataObj;
using ZierbensTetris.Controller;

namespace ZierbensTetris.Model
{
    /// <summary>
    /// 实现如何玩的处理部分
    /// XXX 曾经希望：包含所有处理部分，让存储PlayingModel和处理This分开。
    /// 但是由于发现效率明显减慢，后来才把所有的Pad处理，Ai，及Pad信息 等完全和在一起；
    /// </summary>
    internal partial class PlayingModel
    { 

        internal static Random RAND = new Random(); 
        internal static Color NOITEMCOLOR = Color.White;
        public delegate void SomeThingChanged(int index);
        public SomeThingChanged OneScoreChanged;
        public SomeThingChanged NextItemChanged;
        public SomeThingChanged DropDownModeChanged;
        
        /// <summary>
        /// 玩下一步，不管是人还是电脑，由timer触发的移动均进入到这里
        /// return false gameover
        /// </summary>
        /// <returns></returns>
        public void PlayNextStep()
        {
            if (GameOver)
            {
                GameOverShowNextStep(this);
                return;
            }
            SetOfTetris theMovingSet = TheMovingSet;
           
            if (IsClearingLines)
            {
                //是否是删除特性的情况,如果是,调用删除特性 让所有的clear状态++,当不能加的情况 调用realclear;
                doClear();
            }
            else
            {
                //让当前游戏继续进行一步;
                doGoNextStep();
                //如果是电脑,则让其自动判断下一步;
                if (IsComputer && !GameOver)
                {
                    AIDoNext( Fighters);
                }
            } 
        }

        private void doGoNextStep()
        {
            if (TheMovingState >= 10 - TheLevel)//下降....
            {
                //super....判断的时候可以用
                for (int i = TheMovingSetPosition.Y + 1; i <= (PassThrowMode || TheMovingSet.CanPassThrow ? RowsCount : TheMovingSetPosition.Y + 1); i++)
                {
                    if (PositionIsPermitted( new XYPair(TheMovingSetPosition.X, i), TheMovingSet))
                    {
                        TheMovingSetPosition.Y = i; //下移
                        TheMovingState = 0;     //速度变回;
                        return;
                    }
                }
                GameControllerOfSound.MakeSound(0);
                //到了这里,说明不能移动,必须停止了,这样就要把当前块添加到pad上.
                AddSetToPad(TheMovingSetPosition, TheMovingSet);
                JudgeClear(true,true);
                switchToNextSet();
                if (!PositionIsPermitted(TheMovingSetPosition, TheMovingSet))
                {
                    gameover();
                    return;
                }
            }
            else
            {
                TheMovingState++;
            }
        }
        private int calculateScores(int clearLineCount)
        {
            int re = 100;
            for (int i = 2; i <= clearLineCount; i++)
            {
                re = 2 * re + 100;
            }
            return re;
        }

        private void switchToNextSet()
        { 
            //上一个的路点必须清空，否则可能不能调用下一次AI；
            listRoadPoint.Clear();

            TheMovingSet = TheNextSet;
            TheNextSet = randomOneSet();
            if (NextItemChanged != null) NextItemChanged(index);
            TheMovingState = 0;
            TheMovingSetPosition = new XYPair((int)((ColumnsCount - 3) / 2), -TheMovingSet.StartValueLine);
        }
        /// <summary>
        /// 左移
        /// </summary>
        /// <returns></returns>
        public bool MoveLeft()
        {
            XYPair theNewPosition;
            if (changingJudge(TheMovingSet, TheMovingSetPosition, false, -1, -1, out theNewPosition))
            {
                TheMovingSetPosition = theNewPosition;
                return true;
            }
            return false;
        }
        /// <summary>
        /// 右移
        /// </summary>
        /// <returns></returns>
        public bool MoveRight()
        {
            XYPair theNewPosition;
            if (changingJudge(TheMovingSet, TheMovingSetPosition, false, 1, 1, out theNewPosition))
            {
                TheMovingSetPosition = theNewPosition;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 快速下降
        /// </summary>
        /// <returns></returns>
        public void FasterDrop()
        {
            if (TheMovingSet == null || TheMovingSetPosition == null) return;

            int max = TheMovingSetPosition.Y + 1;//下降直接下的行数;

            //穿越模式下一下到底,
            if (DownToEndMode)
            {
                max = RowsCount - 1;
            }
            for (int i = TheMovingSetPosition.Y; i <= max; i++)
            {
                XYPair theP = new XYPair(TheMovingSetPosition.X, i);
                if (PositionIsPermitted( theP, TheMovingSet))
                {
                    TheMovingSetPosition = theP;
                }
                else if (!PassThrowMode) break;
            }
            TheMovingState = 10;
        }

        public void Fight( PlayingModel theAimPad)
        {
            if (!GameOver && theAimPad != null && ToActLineCount > 0)
            {
                GameControllerOfSound.MakeSound(5);
                theAimPad.AddBottomLines(ToActLineCount);
                ToActLineCount = 0; 
                
            } 
        }
        private bool addALineToBottom()
        {
            //最顶上一行已经有东西了，则失败
            for (int i = 0; i < ColumnsCount; i++)
            {
                if (NowAllPieceState[0]!=0) // if (AllPiece[i, 0].State != -1)
                {
                    return false;
                }
            }
            //所有固定行上升一行
            AllLinesMove(1, RowsCount - 1, -1);

            SetLineToRandom(RowsCount - 1);
            return true;
        }
        /// <summary>
        /// 从某行开始到某行截止，移动指定行
        /// </summary>
        /// <param name="fromLine"></param>
        /// <param name="toLine"></param>
        /// <param name="moveLine"></param>
        public void AllLinesMove(int fromLine, int toLine, int moveLine)
        {
            if (fromLine > toLine || fromLine < 0 || fromLine >= RowsCount || toLine < 0 || toLine >= RowsCount || moveLine == 0 ||
                fromLine + moveLine < 0 || fromLine + moveLine >= RowsCount || toLine + moveLine < 0 || toLine + moveLine >= RowsCount) return;
            if (moveLine > 0)
            {
                for (int i = toLine; i >= fromLine; i--)
                {
                    copyLineToLine(i, i + moveLine);
                }
            }
            else
            {
                for (int i = fromLine; i <= toLine; i++)
                {
                    copyLineToLine(i, i + moveLine);
                }
            }
        }

        /// <summary>
        /// 把某行移动到另一行
        /// </summary>
        /// <param name="fromLine"></param>
        /// <param name="toLine"></param>
        private void copyLineToLine(int fromLine, int toLine)
        {
            //内部调用，不判断
            for (int r = 0; r < ColumnsCount; r++)
            {
                AllPiece[r, toLine].State = AllPiece[r, fromLine].State;
                AllPiece[r, toLine].TheColor = AllPiece[r, fromLine].TheColor;                
            }
            resetNowAllPieceState(fromLine ,toLine);
        }
        /// <summary>
        /// 判断指定位置十分可移动某种方块
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public bool PositionIsPermitted(XYPair position, SetOfTetris theSet)
        {
            if (position == null || theSet == null) return false;
            //遍历所有点，均可则ok            
            foreach (XYPair pointposition in theSet.PositionList)
            {
                try
                {
                    //当位置有效，且状态为空时，可以移动。    
                    if (theSet.StartValueLine < -position.Y) return false;
                    if (position.X + pointposition.X < 0 || position.X + pointposition.X >= columnsCount || position.Y + pointposition.Y >= rowsCount) return false;
                    if (allPiece[position.X + pointposition.X, position.Y + pointposition.Y].State != -1) return false;
                }
                catch
                {
                    return false;
                }
            }
            return true;
        }
        public void AddSetToPad( XYPair position, SetOfTetris theSet)
        {
            if (position == null || theSet == null) return;
            for (int i = 0; i < theSet.PositionList.Count; i++)
            {
                try
                {
                    AllPiece[position.X + theSet.PositionList[i].X, position.Y + theSet.PositionList[i].Y].State = 0;
                    AllPiece[position.X + theSet.PositionList[i].X, position.Y + theSet.PositionList[i].Y].TheColor = theSet.DefaultColor;
                }
                catch
                {
                    throw new Exception("不应该出现超值的现象");
                }
            }
            resetNowAllPieceState(position.Y, position.Y + 3);
        }

        #region 消除部分的语法
        /// <summary>
        /// 判断并根据参数清除可以删除的行
        /// </summary>
        /// <param name="thePad">目标pad</param>
        /// <param name="ifClear">是否真正删除，可能在AI中未必真删</param>
        /// <returns></returns>
        public int JudgeClear(bool ifClear, bool withSound)
        {
            //判断消除....
            List<int> findLine = new List<int>();
            for (int i = 0; i < RowsCount; i++)
            {

                if (NowAllPieceState[i] == fullLineCount)
                {
                    findLine.Add(i);
                }
                // bool holeFound = false;
                //for (int r = 0; r < ColumnsCount; r++)
                //{
                //    if (AllPiece[r, i].State == -1)
                //    {
                //        holeFound = true;
                //        break;
                //    }
                //}
                //if (!holeFound) findLine.Add(i);
            }

            if (findLine.Count > 0 && ifClear) ClearingLines(findLine, withSound);
            return findLine.Count;
        }

        /// <summary>
        /// 对所有需要清除的行进行状态标志
        /// </summary>
        /// <param name="thePad"></param>
        /// <param name="findLines"></param>
        internal void ClearingLines( List<int> findLines,bool withSound)
        {
            IsClearingLines = true;

            if(withSound) GameControllerOfSound.MakeSound(findLines.Count);
            for (int i = 0; i < findLines.Count; i++)
            {
                for (int r = 0; r < ColumnsCount; r++)
                {
                    AllPiece[r, findLines[i]].State = 1;
                }
                nowAllPieceState[findLines[i]] = 0;
            }
        }
      
        /// <summary>
        /// 调用ClearingLines,本方法会一次增加一步clear的步骤,直到结束
        /// </summary>
        /// <param name="thePad"></param>
        private void doClear()
        {
            if (!IsClearingLines) throw new Exception("不在消除状态,不应该进入此处理过程");

            if (CleartingLinesStep == 4)
            {                
                RealClearLines();
                return;
            }
            CleartingLinesStep++;
            for (int r = 0; r < RowsCount; r++)
            {
                if (AllPiece[0, r].State > 0 && AllPiece[0, r].State <= 4)
                {
                    for (int i = 0; i < ColumnsCount; i++)
                        AllPiece[i, r].State = CleartingLinesStep;
                }
            }
        }
        
        /// <summary>
        /// 最终删除所有需要清除的行
        /// </summary>
        /// <param name="thePad"></param>
        /// <param name="findLines"></param>
        internal void RealClearLines()
        {   
            //从最后一行判断，如果状态为该删除的状态则所有之上的行下移当前积累的行数
            IsClearingLines = false;
            CleartingLinesStep = 0;
            int downLines = 0;
            for (int i = RowsCount - 1; i >= 0; i--)
            {
                if (AllPiece[0, i].State > 0 && AllPiece[0, i].State< 5)
                {
                    downLines++;
                    continue;
                }

                for (int r = 0; r < ColumnsCount; r++)
                {
                    AllPiece[r, i + downLines].State = AllPiece[r, i].State;
                    AllPiece[r, i + downLines].TheColor = AllPiece[r, i].TheColor;
                }                
            }
            for (int i = 0; i < downLines; i++)
            {
                for (int r = 0; r < ColumnsCount; r++)
                {
                    AllPiece[r, i].State = -1;
                }
            }
            if (downLines > 0)
            {
                TheScore += calculateScores(downLines);
                ToActLineCount += downLines - 1;
                AllClearLines += downLines;
            }
            if (OneScoreChanged != null) OneScoreChanged(index);

            resetNowAllPieceState(0, rowsCount);
        }
      
        #endregion
        /// <summary>
        /// 初始化整个Pad的数据
        /// </summary>
        public void ClearPad()
        {   //这里会浪费内存,不过由于不会执行多少次就暂时忍了;
            if (AllPiece == null || AllPiece.Length != ColumnsCount * RowsCount)
                AllPiece = new PieceOfPad[ColumnsCount, RowsCount];
            for (int i = 0; i < ColumnsCount; i++)
            {
                for (int r = 0; r < RowsCount; r++)
                {
                    if (AllPiece[i, r] == null)
                    {
                        AllPiece[i, r] = new PieceOfPad();
                    }
                    AllPiece[i, r].TheColor = NOITEMCOLOR;
                    AllPiece[i, r].State = -1;
                }
                nowAllPieceState[i] = 0;
            }
        }
        public void gameover()
        {
            TheMovingSet = null;
            TheNextSet = null;
            GameOver = true;
        }

        public void SetLineToRandom( int line)
        {
            bool haseRole = false;
            for (int i = 0; i < ColumnsCount - 1; i++)
            {
                if (RAND.Next(4) < 3)
                {
                    AllPiece[i, line].State = 0;
                    AllPiece[i, line].TheColor = Color.Gray;
                }
                else
                {
                    AllPiece[i, line].State = -1;
                    AllPiece[i, line].TheColor = NOITEMCOLOR;
                    haseRole = true;
                }
                if (haseRole && RAND.Next(4) < 3)
                {
                    AllPiece[ColumnsCount - 1, line].State = 0;
                    AllPiece[ColumnsCount - 1, line].TheColor = Color.Gray;
                }
                else
                {
                    AllPiece[ColumnsCount - 1, line].State = -1;
                    AllPiece[ColumnsCount - 1, line].TheColor = NOITEMCOLOR;
                }
            }
            resetNowAllPieceState(line, line);
        }


        public void AddBottomLines( int lineCount)
        {
            if (GameOver) return;
            listRoadPoint.Clear();//必须删除路点，重新计算，否则可能造成卡壳
            if (lineCount > 9) lineCount = 9;
            bool needChangeNext = false;
            //让游戏的下降块不动，但是其他固定块上升lineCount，当lineCount>9则赋值9；
            for (int i = 0; i < lineCount; i++)
            {
                if (!PositionIsPermitted(TheMovingSetPosition.Add(new XYPair(0, 1)), TheMovingSet))
                {
                    //所有的上移一行，然后最后一行赋值
                    AddSetToPad(TheMovingSetPosition, TheMovingSet);
                    if (JudgeClear( true,true) > 0)
                        RealClearLines();
                    needChangeNext = true;
                }
                if (!addALineToBottom())
                {
                    gameover();
                    return;
                }
            }
            //为了体现游戏动画效果,可以降低一下效率,一行一行添加;
            //判断当前不动块可以上升多少，
            if (needChangeNext)
            {
                switchToNextSet();
            }
            resetNowAllPieceState(0, rowsCount);
        }

        /// <summary>
        /// 移动或者变化判断
        /// </summary>
        /// <param name="theNewSet">要判断的块</param>
        /// <param name="position">块的最左上角点</param>
        /// <param name="canZero">是否可以横向0移动，当平移时，必须有有效位移，其实不这样做无非浪费几次运算也无所谓</param>
        /// <param name="leftMax">向左最多移动多少</param>
        /// <param name="rightMax">向右最多可以移动多少，变化发生时，如竖条在边缘变横，必须往里移动一定距离</param>
        /// <param name="theNewPosition">返回新位置</param>
        /// <returns>是否可以移动</returns>
        private bool changingJudge( SetOfTetris theNewSet, XYPair position, bool canZero, int leftMax, int rightMax, out XYPair theNewPosition)
        {
            theNewPosition = new XYPair(0, 0);
            if (position == null || theNewSet == null) return false;

            for (int i = (canZero ? 0 : 1); i <= rightMax; i++)
            {
                if (PositionIsPermitted( position.Add(new XYPair(i, 0)), theNewSet))
                {
                    theNewPosition = position.Add(new XYPair(i, 0));
                    return true;
                }
            }            
            for (int i = -1; i >= leftMax; i--)
            {
                if (PositionIsPermitted(position.Add(new XYPair(i, 0)), theNewSet))
                {
                    theNewPosition = position.Add(new XYPair(i, 0));
                    return true;
                }
            }
            
            return false;
        }

        /// <summary>
        /// 转动
        /// </summary>
        /// <returns></returns>
        public bool Turn()
        {
            if (GameOver) return false;
            XYPair theNewPosition;
            SetOfTetris toTrun;
            toTrun = !Hourwise ? TheMovingSet.LeftNext : TheMovingSet.RightNext;
            if (toTrun != null && changingJudge(toTrun, TheMovingSetPosition, true,
                -1 * toTrun.LeftCanMoveWhenErr, toTrun.RightCanMoveWhenErr, out theNewPosition))
            {
                TheMovingSet = toTrun;
                TheMovingSetPosition = theNewPosition;
                return true;
            }
            return false;
        }

        public static void InitPlayingModel(bool useSuperSets)
        {
            SetOfTetris.InitCommonSets();
            if (useSuperSets) SetOfTetris.InitSuperSets();
            // 设置初始化随即的相关内容.            
            initRandomSets(useSuperSets);
        }
        /// <summary>
        /// 初始化游戏
        /// </summary>
        /// <param name="speed">下落速度1~10</param>
        /// <param name="hardLevel">开始难度1~rowCount-5 必须留出5行</param>
        /// <param name="useSuperSets">是否实用超级组，比如十字花Z型拐弯等不规则的形状</param>
        public void StartGame( int speed, int hardLevel)
        {
            GameOver = false;  
            // 设置初始化随即的相关内容.    
            ClearPad();
            initHardLevel(hardLevel);
            //初始化两种方块 
            TheMovingSet = randomOneSet();
            TheMovingSetPosition = new XYPair((int)((ColumnsCount - 3) / 2), 0);
            TheNextSet = randomOneSet();
            listRoadPoint.Clear();
            TheScore = 0;
            AllClearLines = 0;
            TheLevel = speed;
            if (OneScoreChanged != null) OneScoreChanged(index);
        }


        #region 随机形成下一个移动块的相关语法
        static Dictionary<AllTypeOfSets, int> DicValuation = new Dictionary<AllTypeOfSets, int>();//所有不同元素的加权区间,随机后,根据区间分配元素.
        static  int maxValue = 0;
        /// <summary>
        /// 为随机产生方块初始化DicValuation
        /// </summary>
        /// <param name="useSuper"></param>
        private static  void initRandomSets(bool useSuper)
        {
            int count = SetOfTetris.DicAll.Count;
            DicValuation.Clear();

            maxValue = 0;
            foreach (AllTypeOfSets theType in SetOfTetris.DicAll.Keys)
            {
                maxValue += useSuper ? SetOfTetris.DicAll[theType][0].ValuationWithSuper : SetOfTetris.DicAll[theType][0].Valuation;
                DicValuation.Add(theType, maxValue);
            }

        }

        /// <summary>
        /// 随即形成一个图形,这里都用抛异常的方式处理错误,由于这些错误理应不会出现!
        /// </summary>
        /// <returns></returns>
        internal SetOfTetris randomOneSet()
        {
            if (DicValuation.Count != SetOfTetris.DicAll.Count)
                throw new Exception("不应该出现随即临时缓冲列表的条目与初始化过的图形数不一致的情况!");

            //得到一个随机数;
            int rValue = RAND.Next(maxValue);
            //根据不同权值划定的空间范围在随即后落入的区域就是选中的值.
            foreach (AllTypeOfSets theType in SetOfTetris.DicAll.Keys)
            {
                if (rValue <= DicValuation[theType])
                {
                    return SetOfTetris.DicAll[theType][RAND.Next(SetOfTetris.DicAll[theType][0].CanChangeTimes)];
                }
                continue;
            }
            throw new Exception("没有发现任何符合随即条件的值,随即算法有问题!");
        }
        #endregion

      
        /// <summary>
        /// 初始化难度
        /// </summary>
        /// <param name="thePad"></param>
        /// <param name="hardLevel"></param>
        private void initHardLevel( int hardLevel)
        {
            //从最后一行开始,以4/5的概率添加小块.
            for (int i = RowsCount - 1; i >= RowsCount - hardLevel; i--)
            {
                SetLineToRandom(i);
            }
        } 
    }
}
