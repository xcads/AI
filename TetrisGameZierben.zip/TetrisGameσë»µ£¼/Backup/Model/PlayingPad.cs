﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Drawing;
using System.Text;
using ZierbensTetris.DataObj;
using ZierbensTetris.Controller;

namespace ZierbensTetris.Model
{
    /// <summary>
    /// 存储某一个玩家的所有状态，并不做任何处理业务
    /// </summary>
     internal partial class PlayingModel: ICloneable 
    {
        int index;     
        int rowsCount;
        int columnsCount;
        int fullLineCount=0;
        private bool isComputer = false;
        private int theLevel = 0;//max is 9 
        PieceOfPad[,] allPiece;//所有固定块    
        List<int> nowAllPieceState = new List<int> ();//记录每一行的状态，每一行用一个int表示，最大为2的10次方-1 = 1023
        SetOfTetris theMovingSet;
        SetOfTetris theNextSet;        
        XYPair theMovingSetPosition;
        int theMovingState = 0;
        bool passThrowMode = false;//穿越模式开关     
        bool downToEndMode = false;//下为:直接到底的模式     
        bool hourwise = true;//顺时针转动       
        bool gameOver = true; 
        private int toActLineCount = 0;//可以攻击对方的行数      

        int allClearLines;
        int theScore;
       
        private List<PlayingModel> fighters = new List<PlayingModel>();
        bool isClearingLines = false;
        int cleartingLinesStep = 0;//当isClearingLines为true时有效,值为1,2,3,4与PieceOfPad的state消除区域对应
        int gameOverEffectState = 0;//0添加  1清空 2下降
        int gameOverStep = 0;//相当于内部迭代器，在 添加过程，表示添加到哪行，清空过程表示清空到哪行，下降过程表示下降到哪里
       

        #region 属性区域
        /// <summary>
        /// 当前对应第几玩家
        /// </summary>
        public int Index
        {
            get { return index; }
            set { index = value; }
        }

        /// <summary>
        /// 正在移动的块
        /// </summary>
        public SetOfTetris TheMovingSet
        {
            get { return theMovingSet; }
            set { theMovingSet = value; }
        }
        /// <summary>
        /// 下一个要移动的块
        /// </summary>
        public SetOfTetris TheNextSet
        {
            get { return theNextSet; }
            set { theNextSet = value; }
        }
        /// <summary>
        /// 正在移动的块的位置
        /// </summary>
        public XYPair TheMovingSetPosition
        {
            get { return theMovingSetPosition; }
            set { theMovingSetPosition = value; }
        }
        /// <summary>
        /// 当前游戏区域有多少横行
        /// </summary>
        public int RowsCount
        {
            get { return rowsCount; }
            set { rowsCount = value; }
        }
        /// <summary>
        /// 当前游戏区域有多少竖列
        /// </summary>
        public int ColumnsCount
        {
            get { return columnsCount; }
            set { columnsCount = value; }
        }
        public bool IsComputer
        {
            get { return isComputer; }
            set { isComputer = value; }
        }
        public int TheLevel
        {
            get { return theLevel; }
            set { theLevel = value; }
        }
        /// <summary>
        /// 所有的固定块,包含位置和颜色及状态等
        /// </summary>
        public PieceOfPad[,] AllPiece
        {
            get { return allPiece; }
            set { allPiece = value; }
        }

        public List<int> NowAllPieceState
        {
            get { return nowAllPieceState; }
            set { nowAllPieceState = value; }
        }
        /// <summary>
        ///  状态,0,1,2,3,4,5,6,7,8,9,10，9999 stop 10帧后下落，到达下落状态就下落，如果不能下落就终止移动，速度10的情况下，一帧下一次 
        /// </summary>
        public int TheMovingState
        {
            get { return theMovingState; }
            set { theMovingState = value; }
        }

        public int ToActLineCount
        {
            get { return toActLineCount; }
            set { toActLineCount = value; }
        }
        public bool PassThrowMode
        {
            get { return passThrowMode; }
            set { passThrowMode = value; }
        }
        public bool DownToEndMode
        {
            get { return downToEndMode; }
            set { downToEndMode = value; }
        }
        public bool GameOver
        {
            get { return gameOver; }
            set { gameOver = value; }
        }
        public bool Hourwise
        {
            get { return hourwise; }
            set { hourwise = value; }
        }

        public int AllClearLines
        {
            get { return allClearLines; }
            set { allClearLines = value; }
        }

        public int TheScore
        {
            get { return theScore; }
            set { theScore = value; }
        }
 
        public bool IsClearingLines
        {
            get { return isClearingLines; }
            set { isClearingLines = value; }
        }


        public int CleartingLinesStep
        {
            get { return cleartingLinesStep; }
            set { cleartingLinesStep = value; }
        }
        /// <summary>
        /// 0添加  1清空 2下降
        /// </summary>
        public int GameOverEffectState
        {
            get { return gameOverEffectState; }
            set { gameOverEffectState = value; }
        }
        /// <summary>
        /// 相当于内部迭代器，在 添加过程，表示添加到哪行，清空过程表示清空到哪行，下降过程表示下降到哪里
        /// </summary>
        public int GameOverStep
        {
            get { return gameOverStep; }
            set { gameOverStep = value; }
        }
 

        public List<PlayingModel> Fighters
        {
            get { return fighters; }
            set { fighters = value; }
        }

       
        #endregion


        public void resetNowAllPieceState(int fromRow,int endRow)
        {
            for (int i = (fromRow < 0 ? 0 : fromRow); i <= (endRow > rowsCount - 1 ? rowsCount - 1 : endRow); i++)
            {
                nowAllPieceState[i] = 0;
                for (int r = 0; r < columnsCount; r++)
                {
                    //如果有东西，则加上1向左位移其相应列 （最左边的列为0，移动columnCount-1）
                    nowAllPieceState[i] = nowAllPieceState[i] | ((allPiece[r, i].State == 0) ? 1 << (columnsCount - 1 - r) : 0);                   
                }
            }            
        }
        public PlayingModel()
            : this(22, 10)
        {

        }
        public PlayingModel(int rowCount, int columnCount) 
        {
            this.rowsCount = rowCount;
            this.columnsCount = columnCount;
            nowAllPieceState.Clear();
            fullLineCount = (1 << columnCount) - 1;
            for (int i = 0; i < rowsCount; i++)
            {
                nowAllPieceState.Add(0);                
            }
            
        }



        #region ICloneable 成员

        public object Clone()
        {
            PlayingModel beCloneOne = new PlayingModel(rowsCount, columnsCount);
            beCloneOne.AllPiece = new PieceOfPad[columnsCount, rowsCount];
            // allPiece;//所有固定块
            for (int i = 0; i < columnsCount; i++)
            {
                for (int r = 0; r < rowsCount; r++)
                {
                    beCloneOne.allPiece[i, r] = (PieceOfPad)allPiece[i, r].Clone();
                }
            }
            beCloneOne.Index = this.index ; 
            beCloneOne.TheMovingSet = this.theMovingSet;
            beCloneOne.theNextSet = this.theNextSet;
            beCloneOne.theMovingSetPosition = (XYPair)this.theMovingSetPosition.Clone();
            beCloneOne.theMovingState = this.theMovingState;
            return beCloneOne;
        }

        #endregion
    }
}
