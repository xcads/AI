﻿using System;
using System.Collections.Generic;
using System.Text;
using ZierbensTetris.DataObj;
using ZierbensTetris.Controller;

namespace ZierbensTetris.Model
{
    internal partial class PlayingModel
    {

        #region 评价参数区域
        //策略 说明
        //1 紧密防守。。。 一行也消除
        //2 频繁小规模进攻。。。以2行起消，消一行不加分也不扣分 已经不讨论这种了,默认就两种测量
        //3 积攒大规模进攻。。。以3行起消，消两行不加分，消一行扣分，消四行得高分 
        int plot = 3; //默认策略是3 
        int calculateCount = 40;//取几个最优值进行下一个方块的计算
        List<WayPoint> listRoadPoint = new List<WayPoint>();//路点
        //数值为素数比较好，这样计算的过程中会更不容易计算出重复值        
        int sameLevel = 2; //平台，越多越好
        int RealHole = -35; //实洞       
        int NoHigher1 = -2;//无左高台评价 对于有些图形，无高低台反而不方便 
        int Higher2 = -5; //多于3个2阶高 
        int Higher3 = -7; //有超过一个3阶以上的高台 Higher3 * (个数-1)^2 * (高出来的长度 -6)
        int HighLowDisOver6 = -13;//最高和最低点差6以上
        int HightMoreThan13 = -17;//高度超过13以后扣分平方关系
        int SideIsVeryLowerwhenHigh = -45;//当特别高的时候（如>14)当边上依然比中间低，则扣分 从外往里看均为如此。 这个比实洞还严格 但是应该是 平方或者立方上升，如果有个3个2个的无所谓

        #endregion

        #region 评价函数 实现

        /// <summary>
        /// 算洞的评价
        /// </summary>
        /// <param name="allPieceToevaluate"></param>
        /// <returns></returns>
        private int calculateHole(List<int> allPieceToevaluate)
        {
            double allCount = 0; //真洞  
            #region 从最边上一列 挨个查看 有多少空格 这样计算出来的是所有洞，即使是可以填上的假洞，也当成洞来计算。
            for (int i = 0; i < columnsCount; i++)
            {
                bool findFirst = false;
                int howDeep = 0;
                for (int r = 0; r < rowsCount; r++)
                {
                    if (!findFirst)
                    {
                        if ((allPieceToevaluate[r] & (1 << (columnsCount - 1 - i))) != 0)
                            findFirst = true;
                    }
                    else
                    {
                        if ((allPieceToevaluate[r] & (1 << (columnsCount - 1 - i))) == 0)
                        {
                            allCount += 1.0 + howDeep * 0.13; // 实际是 (1+ 0.1 * howDeep) 其中0.13是惩罚系数，不宜过大，否则将来对分数影响过深！
                        }
                        else if (howDeep < 4) howDeep++;
                    }
                }
            }
            return (int)(allCount * RealHole);
            #endregion
        }

        private int calculateClearLines(int clearLinesCount)
        {
			if (clearLinesCount > 3) return 9000;
            else if (clearLinesCount == 3) return 5000;
            
            int finalValue = 0;
            switch (plot)
            {
                case 1:
                    if (clearLinesCount == 1)
                        finalValue += 13;//略小于产生空格。
                    else if (clearLinesCount == 2)
                        finalValue += 27;
                    break; 
                default:
                    if (clearLinesCount == 1)
                        finalValue -= 10; //不如一个洞扣分多，否则它会宁愿给洞都不消除行
                    break;
            }
            return finalValue;
        }
        /// <summary>
        /// 算上下距离的评价
        /// </summary>
        /// <param name="allPieceToevaluate">每一列的内容</param>
        /// <returns></returns>
        private int calculateDistanceOfHighLow(List<int> allPieceToevaluate)
        {
            int calculateValue = 0;//结果值
            int dislong = 0;//临近高于3个的数量 深沟必须
            int dislongtotal = 0;
            int dis2 = 0; //高于2个的数量
            int disleft1 = 0;//左高于1个的数量
            int disright1 = 0;//右高于1个的数量
            int dis0 = 0;//平台的数量 
            int max;//最高点 // 指每一列最顶端的所在位置中最高点
            int min;//最低点 // 指每一列最顶端的所在位置中最低点
            List<int> allColumnFirstPoint = new List<int>();

            for (int i = 0; i < columnsCount; i++)
            {
                for (int r = 0; r < rowsCount; r++)
                {
                    if ((allPieceToevaluate[r] & (1 << i)) != 0)
                    {
                        allColumnFirstPoint.Add(r);
                        break;
                    }
                }
                if (allColumnFirstPoint.Count <= i)
                    allColumnFirstPoint.Add(GameController.TheController.RowsCount - 1);
            }


            int lasta = allColumnFirstPoint[0];
            int lastDis = allColumnFirstPoint[0];
            max = lasta;
            min = lasta;

            for (int i = 1; i < allColumnFirstPoint.Count; i++)
            {
                if (max < allColumnFirstPoint[i]) max = allColumnFirstPoint[i];
                else if (min > allColumnFirstPoint[i]) min = allColumnFirstPoint[i];

                lastDis = allColumnFirstPoint[i] - lasta;
                switch (lastDis)
                {
                    case 0:
                        dis0++;
                        break;
                    case 1:
                        disright1++;
                        break;
                    case -1:
                        disleft1++;
                        break;
                    case 2:
                        dis2++;
                        break;
                    case -2:
                        dis2++;
                        break;
                    default:
                        if (i + 1 >= columnsCount || i == 1)
                        {
                            dislong++;
                            dislongtotal += Math.Abs(lastDis);
                        }
                        else if (Math.Abs(allColumnFirstPoint[i + 1] - allColumnFirstPoint[i]) > 3)
                        {
                            dislong++;
                            dislongtotal += Math.Abs(allColumnFirstPoint[i + 1] - allColumnFirstPoint[i]) > Math.Abs(lastDis) ? Math.Abs(allColumnFirstPoint[i + 1] - allColumnFirstPoint[i]) : Math.Abs(lastDis);
                        }
                        break;
                }
                lasta = allColumnFirstPoint[i];
            }
            if (min < 7)
            {
                int sideLowerThanMiddle = 0;
                for (int i = 0; i < columnsCount / 2; i++)
                {
                    //从外往内，只要低于中间的，就扣分，低多少扣击个 
                    if (allColumnFirstPoint[i + 1] < 7 && allColumnFirstPoint[i] > allColumnFirstPoint[i + 1] + 1)
                        sideLowerThanMiddle += allColumnFirstPoint[i] - allColumnFirstPoint[i + 1];
                }
                for (int i = columnsCount - 1; i > columnsCount / 2; i--)
                {
                    //从外往内，只要低于中间的，就扣分，低多少扣击个
                    if (allColumnFirstPoint[i - 1] < 7 && allColumnFirstPoint[i] > allColumnFirstPoint[i - 1] + 1)
                        sideLowerThanMiddle += allColumnFirstPoint[i] - allColumnFirstPoint[i - 1];
                }
                if (sideLowerThanMiddle > 4)
                {
                    calculateValue += (sideLowerThanMiddle - 3) * (sideLowerThanMiddle - 4) * SideIsVeryLowerwhenHigh;
                }
            }
            if (dislongtotal > 6) calculateValue += Higher3 * (dislongtotal - 5);
            if (dis2 > 3) calculateValue += dis2 * Higher2;
            if (disleft1 == 0) calculateValue += NoHigher1;
            if (disright1 == 0) calculateValue += NoHigher1;
            else calculateValue += sameLevel * dis0;
            if (max - min > 6) calculateValue += (max - min - 4) * (max - min - 5) * HighLowDisOver6;
            if (min < 10) calculateValue += (12 - min) * (12 - min) * HightMoreThan13;
            return calculateValue;
        }

        /// <summary>
        /// 评价函数
        /// 注意：评价函数不考虑将来，仅对当前状态进行评价。
        /// </summary>
        private int evaluateFunction(ref List<int> insideCalcluateArray, out int clearLinesCount)
        {
            //计算当前这次消除行的加分
            int finalValue = 0;
            clearLinesCount = clearLinesToInsideCalcluateArray(ref insideCalcluateArray);
            //调用上面的三个个评价函数   
            finalValue += calculateClearLines(clearLinesCount);
            finalValue += calculateDistanceOfHighLow(insideCalcluateArray);
            finalValue += calculateHole(insideCalcluateArray);

            return finalValue;
        }
        #endregion

        #region  调用 AI之前的内容

        /// <summary>
        /// 此函数是外面界面设置内部存储计算
        /// </summary>
        internal int AILevel
        {
            set
            {
                switch (value)
                {
                    case 1:
                        calculateCount = 4;
                        break;
                    case 3:
                        calculateCount = 40;
                        break;
                    default:
                        calculateCount = 10;
                        break;
                }
            }
        }
        /// <summary>
        /// 判断一个pad的最高位置,不进行异常处理
        /// </summary>
        /// <param name="theModel"></param>
        /// <returns></returns>
        private int getPadHight(List<int> nowSituate)
        {
            //int min = rowsCount;
            for (int r = 0; r < RowsCount; r++)
            {
                if (nowSituate[r] != 0) return r;
            }
            return rowsCount;
        }
        int nowStopCount = 0;
		//全局变量nowStopCount,用于记录电脑的停顿次数,当电脑不是智能很高的时候,
		//为了不让电脑太过分,加入了此变量,让他反应慢一些的,但是最高级的情况下,它是不起作用的
		
        internal void AIDoNext(List<PlayingModel> fighters)
        {
            for (int i = fighters.Count - 1; i >= 0; i--)
            {
                if (fighters[i] == null || fighters[i].GameOver) fighters.RemoveAt(i);
            }
            if (nowStopCount < plot && nowStopCount < 10 - theLevel && listRoadPoint.Count <2) { nowStopCount++; return; }
            nowStopCount = 0;
            if (ToActLineCount > 0)
            {
                //找到任意一个敌人,只要满足条件就攻击
                foreach (PlayingModel tempPad in fighters)
                {
                    int min = tempPad.getPadHight(tempPad.NowAllPieceState);
                    if (min - ToActLineCount < 8 || plot == 1)
                    {
                        Fight(tempPad);
                        OneScoreChanged(index);
                        //攻击完毕就结束,如果多于一个敌人的,以后可以攻击一部分,剩下的攻击其他人
                        break;
                    }
                }
            }
            
            //1\判断路点是否达到，如果全部达到，则进行AI
            //2\如果路点的方块和当前方块不是一个，也重新计算，否则永远也旋转不到相应位置
            //不再有效 3\如果还有路点存在，则判断是否可以正常达到路点，特别是横向移动是否有阻碍，
            //比如本来可以移动的，但是由于对方给这边加入了一些行，造成无法移动，则不得不重新调用AI
           // List<WayPoint> temp;
            if (listRoadPoint.Count == 0 || listRoadPoint[0].TheAimSet.TheType != this.theMovingSet.TheType
             //|| !AStarMethod(nowSituation, listRoadPoint[0].TheAimPoint, listRoadPoint[0].TheAimSet, TheMovingSetPosition, theMovingSet, out temp))
			 //注释掉上一句的原因是让逻辑运算更简练,避免大量的内部计算!
             || listRoadPoint[0].TheAimPoint.Y < TheMovingSetPosition.Y )
            {
               
                AI(fighters);
                nowStopCount = 5;
                return;
            }

            //如果可以移动到路点，则进行一次移动操作
            //如果需要移动到路点后继续横移（就是要填充虚洞的操作，先移动下去，然后快速横移）则调整成慢下降，否则调整成快下降模式           
            if (listRoadPoint[0].TheAimSet != TheMovingSet)
            {
                //这里判断左变，右变；
                if (listRoadPoint[0].TheAimSet == TheMovingSet.RightNext)
                {
                    this.Hourwise = true;
                }
                else
                {
                    this.Hourwise = false;
                }
                Turn();
                nowStopCount = 5;
                return;
            }
           
            if (listRoadPoint.Count == 1)
            {
                if (calculateCount > 6) //在初级电脑里不要是用这个，所以用了>6
                {
                    downToEndMode = true;
                    if (DropDownModeChanged != null) DropDownModeChanged(index);
                }
            }
            else
            {
                downToEndMode = false;
                if (DropDownModeChanged != null) DropDownModeChanged(index);
            }

            //删除了原先定义的 先横移 先纵向移动的属性，全部都是先横移，原先竖向，再横向的，拆成两步即可。
            if (listRoadPoint[0].TheAimPoint.X != TheMovingSetPosition.X)
                moveHorizontalToAim(listRoadPoint[0].TheAimPoint.X);
            else
                moveVerticalToAim(listRoadPoint[0].TheAimPoint.Y);

            if (listRoadPoint[0].TheAimPoint.Equals(TheMovingSetPosition))
            {
                listRoadPoint.RemoveAt(0);
                //为了避免它再移动，当走到这里，没有路点的情况下，则下降操作；
                if (listRoadPoint.Count == 0) FasterDrop();
            }
        }
        /// <summary>
        /// 横向移动到目的地
        /// </summary>
        /// <param name="aimHorizontalValue"></param>
        private void moveHorizontalToAim(int aimHorizontalValue)
        {
            if (aimHorizontalValue > TheMovingSetPosition.X)
            {
                MoveRight();
                return;
            }
            else
            {
                MoveLeft();
                return;
            }
        }
        /// <summary>
        /// 竖向移动到目的地
        /// </summary>
        /// <param name="aimVerticalValue"></param>
        private void moveVerticalToAim(int aimVerticalValue)
        {
            if (aimVerticalValue > TheMovingSetPosition.Y + 2)
            {
                FasterDrop();
                return;
            }
        }

        #endregion

        #region Ex_A* Method 变形的A*算法
        //得到一个位置加方块的哈希值,这对于快速定位列表中是否存在将要评价的节点有很关键的作用
        private int getHashValueOfAPoint(XYPair position, SetOfTetris theTetris)
        {
            // << 4 留出4位给横向坐标使用 << 5 留出 5位给竖向坐标使用
            return (theTetris.GetHashCode() << 4 | position.X) << 5 | position.Y;
        }
        private bool AStarMethod(List<int> nowSituation, XYPair AimPosition, SetOfTetris theAimTetris, XYPair theDroppingPosition, SetOfTetris theDroppingTetris, out List<WayPoint> theRoad)
        {
            theRoad = new List<WayPoint>();
            Dictionary<int, MapPoint> OpenPoint = new Dictionary<int, MapPoint>();
            Dictionary<int, MapPoint> ClosePoint = new Dictionary<int, MapPoint>();
            // Dictionary <int,int> allIndexs = new Dictionary<int,int>();//作为所有已经添加元素的索引,如果重复了则不能添加;value表达到达此的最小距离             
            OpenPoint.Add(getHashValueOfAPoint(theDroppingPosition, theDroppingTetris),
                new MapPoint(theDroppingPosition, theDroppingTetris, AimPosition, theAimTetris, 0, 0, null));

            int theAimHash = getHashValueOfAPoint(AimPosition, theAimTetris);
            bool finish = false;
            #region toFindThePath
            while (!finish && OpenPoint.Count > 0)
            {
                finish = true;
                int theOperKey = 0;
                MapPoint theMostSmallestPoint = null;
                //找到FullCost最小的点;
                foreach (int theTempKey in OpenPoint.Keys)
                {
                    if (theMostSmallestPoint == null || theMostSmallestPoint.FullCost >= OpenPoint[theTempKey].FullCost)
                    {
                        theOperKey = theTempKey;
                        theMostSmallestPoint = OpenPoint[theTempKey];
                    }
                }
                if (theMostSmallestPoint == null || theOperKey == 0) return false;
                OpenPoint.Remove(theOperKey);
                ClosePoint.Add(theOperKey, theMostSmallestPoint);

                //判断其可能的下一步,并分别添加到OpenPoint中; 
                //下移一次10分;横向移动,按照越高,横向连续次数越多扣分越多,5*高度*横移次数 + 10 ;变形一次15
                //横向这样处理是避免竖条一类的长时间横向移动,造成卡住的现象!
                //下移
                XYPair newPosition = theMostSmallestPoint.Position.Add(new XYPair(0, 1));
                int theHash;
                int theValue;
                if (insidePositionIsPermit(nowSituation, newPosition, theMostSmallestPoint.TheTetris))
                {
                    //得到目标位置的哈希值
                    theHash = getHashValueOfAPoint(newPosition, theMostSmallestPoint.TheTetris);
                    //得到到达它这一步所花费的实际路径值
                    theValue = theMostSmallestPoint.NowCost + 10;
                    //如果在两个集合中没有找到这个点,才继续进行
                    if (!OpenPoint.ContainsKey(theHash) && !ClosePoint.ContainsKey(theHash))
                    {
                        finish = false;
                        //为open列表添加节点
                        OpenPoint.Add(theHash, new MapPoint(newPosition, theMostSmallestPoint.TheTetris, AimPosition, theAimTetris, theValue, 0, theMostSmallestPoint));
                    }
                    //当在Open集合中找到,则判断它是否有必要更新给Open列表
                    else if (OpenPoint.ContainsKey(theHash) && OpenPoint[theHash].NowCost > theValue)
                    {
                        OpenPoint[theHash].NowCost = theValue;
                        OpenPoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    //当在close集合中找到,则判断它是否有必要更新给Close列表
                    else if (ClosePoint.ContainsKey(theHash) && ClosePoint[theHash].NowCost > theValue)
                    {
                        ClosePoint[theHash].NowCost = theValue;
                        ClosePoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    //如果找到了目标节点,则退出
                    if (theHash == theAimHash) break;
                }
                //右移
                newPosition = theMostSmallestPoint.Position.Add(new XYPair(1, 0));
                if (insidePositionIsPermit(nowSituation, newPosition, theMostSmallestPoint.TheTetris))
                {
                    theHash = getHashValueOfAPoint(newPosition, theMostSmallestPoint.TheTetris);
                    theValue = theMostSmallestPoint.HorizontalTimes * theMostSmallestPoint.TheTetris.Height * 5 + theMostSmallestPoint.NowCost + 10;
                    if (!OpenPoint.ContainsKey(theHash) && !ClosePoint.ContainsKey(theHash))
                    {
                        finish = false;
                        OpenPoint.Add(theHash, new MapPoint(newPosition, theMostSmallestPoint.TheTetris, AimPosition, theAimTetris,
                            theValue, theMostSmallestPoint.HorizontalTimes + 1, theMostSmallestPoint));
                    }
                    else if (OpenPoint.ContainsKey(theHash) && OpenPoint[theHash].NowCost > theValue)
                    {
                        OpenPoint[theHash].NowCost = theValue;
                        OpenPoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    else if (ClosePoint.ContainsKey(theHash) && ClosePoint[theHash].NowCost > theValue)
                    {
                        ClosePoint[theHash].NowCost = theValue;
                        ClosePoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    if (theHash == theAimHash) break;
                }
                //左移
                newPosition = theMostSmallestPoint.Position.Add(new XYPair(-1, 0));
                if (insidePositionIsPermit(nowSituation, newPosition, theMostSmallestPoint.TheTetris))
                {
                    theHash = getHashValueOfAPoint(newPosition, theMostSmallestPoint.TheTetris);
                    theValue = theMostSmallestPoint.HorizontalTimes * theMostSmallestPoint.TheTetris.Height * 5 + theMostSmallestPoint.NowCost + 10;
                    if (!OpenPoint.ContainsKey(theHash) && !ClosePoint.ContainsKey(theHash))
                    {
                        finish = false;
                        OpenPoint.Add(theHash, new MapPoint(newPosition, theMostSmallestPoint.TheTetris, AimPosition, theAimTetris,
                           theValue, theMostSmallestPoint.HorizontalTimes + 1, theMostSmallestPoint));
                    }
                    else if (OpenPoint.ContainsKey(theHash) && OpenPoint[theHash].NowCost > theValue)
                    {
                        OpenPoint[theHash].NowCost = theValue;
                        OpenPoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    else if (ClosePoint.ContainsKey(theHash) && ClosePoint[theHash].NowCost > theValue)
                    {
                        ClosePoint[theHash].NowCost = theValue;
                        ClosePoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    if (theHash == theAimHash) break;
                }
                //左变形
                newPosition = theMostSmallestPoint.Position;
                if (insidePositionIsPermit(nowSituation, newPosition, theMostSmallestPoint.TheTetris.LeftNext))
                {
                    theHash = getHashValueOfAPoint(newPosition, theMostSmallestPoint.TheTetris.LeftNext);
                    theValue = theMostSmallestPoint.NowCost + 15;
                    if (!OpenPoint.ContainsKey(theHash) && !ClosePoint.ContainsKey(theHash))
                    {
                        finish = false;
                        OpenPoint.Add(theHash, new MapPoint(newPosition, theMostSmallestPoint.TheTetris.LeftNext, AimPosition, theAimTetris,
                          theValue, theMostSmallestPoint.HorizontalTimes + 1, theMostSmallestPoint));
                    }
                    else if (OpenPoint.ContainsKey(theHash) && OpenPoint[theHash].NowCost > theValue)
                    {
                        OpenPoint[theHash].NowCost = theValue;
                        OpenPoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    else if (ClosePoint.ContainsKey(theHash) && ClosePoint[theHash].NowCost > theValue)
                    {
                        ClosePoint[theHash].NowCost = theValue;
                        ClosePoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    if (theHash == theAimHash) break;
                }
                //右变形 
                if (insidePositionIsPermit(nowSituation, newPosition, theMostSmallestPoint.TheTetris.RightNext))
                {
                    theHash = getHashValueOfAPoint(newPosition, theMostSmallestPoint.TheTetris.RightNext);
                    theValue = theMostSmallestPoint.NowCost + 15;
                    if (!OpenPoint.ContainsKey(theHash) && !ClosePoint.ContainsKey(theHash))
                    {
                        finish = false;
                        OpenPoint.Add(theHash, new MapPoint(newPosition, theMostSmallestPoint.TheTetris.RightNext, AimPosition, theAimTetris,
                            theValue, theMostSmallestPoint.HorizontalTimes + 1, theMostSmallestPoint));
                    }
                    else if (OpenPoint.ContainsKey(theHash) && OpenPoint[theHash].NowCost > theValue)
                    {
                        OpenPoint[theHash].NowCost = theValue;
                        OpenPoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    else if (ClosePoint.ContainsKey(theHash) && ClosePoint[theHash].NowCost > theValue)
                    {
                        ClosePoint[theHash].NowCost = theValue;
                        ClosePoint[theHash].TheComePoint = theMostSmallestPoint;
                    }
                    if (theHash == theAimHash) break;
                }

            }
            #endregion
            if (!OpenPoint.ContainsKey(theAimHash)) return false;//说明没有找到
            #region 找到路点
            //从路点开始往回找,一直其周边最小的,正常应该在close里面找,不再回到敞开式里的了
            MapPoint theAimPoint = OpenPoint[theAimHash];
            WayPoint endWay = new WayPoint(theAimPoint.Position, theAimPoint.TheTetris);
            theRoad.Insert(0, endWay);
            while (theAimPoint != null && theAimPoint.TheComePoint != null)
            {
                //当时往上走的时候,不切换路点,否则根据变化切换
                if (theAimPoint.TheTetris != theAimPoint.TheComePoint.TheTetris || theAimPoint.Position.X != theAimPoint.TheComePoint.Position.X)
                {
                    WayPoint oneTempWay = new WayPoint(theAimPoint.TheComePoint.Position, theAimPoint.TheComePoint.TheTetris);
                    theRoad.Insert(0, oneTempWay);
                }
                theAimPoint = theAimPoint.TheComePoint;
            }
            #endregion
            return true;
        }
        #endregion

        #region AI 部分
        /// <summary>
        /// 智能计算调用的方法
        /// 当完成一次操作以后，进行此AI计算,由于路点形成的之前，已经计算了它的可行性，所以不再考虑路点不能实现造成的影响
        /// 当实在不能实现的时候，再补充相关操作。
        /// ---------------------------------------------------------------------------
        /// 为了降低对cpu的影响，采用剪枝时，仅采集固定个数个最优方案进行二次评价（由于知道当前块和下一个块）仅能进行2次评价，无法递归
        /// </summary>
        /// <param name="thePadToCalculate">当前游戏状态</param>
        /// <param name="notGivenRowsCount">对方没有给过来的行数</param>
        /// <returns></returns>
        private void AI(List<PlayingModel> fighters)
        {
            //这个不需要外部计算,直接在内部定义即可;
            List<int> nowSituation = insideCalcluateArray(this);
            int notGivenRowsCount = 0;
            bool haveEnemy = false;
            foreach (PlayingModel tempPad in fighters)
            {
                notGivenRowsCount += tempPad.ToActLineCount;
                if (!haveEnemy && !tempPad.GameOver) haveEnemy = true;
            }
            //清空路点
            listRoadPoint.Clear();
            int min = getPadHight(nowAllPieceState);
			//高度 + 对方可以给我们消除的行的数 的和 是当前理论高度(随时对方可以释放),
			//当这个值小于7行的情况下,也就是实际上的移动空间已经很小了,采用1的模式,鼓励消行,其他情况是3,鼓励积攒
            if (min - notGivenRowsCount < 7) plot = 1; 
            else plot = 3;
            //下面是查找做好的路径,
            //首先找第一步,最好的一组解
            List<FindBestWay> findBestWays = AIinside(nowSituation,TheMovingSet,TheMovingSetPosition,calculateCount);
            FindBestWay theBestOne = null;
            int bestWayValue = -1000000000;
            //循环找到的最好解,把第二个方块给他,让其找最优解
            foreach (FindBestWay tempBestWays in findBestWays)
            {
                List<FindBestWay> tempFindSecondBestWays = AIinside(tempBestWays.TheSituation, this.TheNextSet, new XYPair(3, -TheNextSet.StartValueLine), 1);                
                if (tempFindSecondBestWays.Count == 0) continue;
                if (theBestOne == null || bestWayValue < tempFindSecondBestWays[0].WayValue)
                {
                    theBestOne = tempBestWays;
                    bestWayValue = tempFindSecondBestWays[0].WayValue;
                }
                else if (theBestOne != null && bestWayValue == tempFindSecondBestWays[0].WayValue && theBestOne.WayValue < tempBestWays.WayValue)
                { 
                    //当两步走下来分数一样,则优先选择第一步分数比较高的,这样避免电脑先走险招....
                    theBestOne = tempBestWays;
                    bestWayValue = tempFindSecondBestWays[0].WayValue; 
                }
            }
            if (theBestOne != null) //为null就只有等死...或者已经死了;
            {
                listRoadPoint.Clear();
                listRoadPoint = theBestOne.TheWay;
                //AStarMethod(nowSituation, theBestOne.AimPosition, theBestOne.AimSet, TheMovingSetPosition, TheMovingSet, out listRoadPoint);
            }            
        }
        /// <summary>
        /// 只能计算递归用的，但是由于只知道下一个牌，所以并不能递归超过2次。
        /// </summary>
        /// <param name="thePadToCalculate">要计算的形式</param>
        /// <param name="startAiPosition">起始计算位置</param>
        /// <param name="deep">2或1</param>
        /// <returns></returns>
        private List<FindBestWay> AIinside(List<int> nowSituation, SetOfTetris inFunctionSet, XYPair startAiPosition, int bestCount)
        {
            List<FindBestWay> findBestWays = new List<FindBestWay>();         

            int theHeightOfNow = getPadHight(nowSituation);           
            //把当前图形所有可以变化的样式测试个遍          
            SetOfTetris toCalculateSet = inFunctionSet.RightNext;
            //这样赋值一下 避免直接把参数进行操作,现在是个对象引用,以后赋值,也是这个引用在操作,而不是原对象
            //赋值其向右,是为了让下面赋值往左的操作在第一次计算的时候还是其原样,实际没有更高的意义.

            for (int rotation = 0; rotation < toCalculateSet.CanChangeTimes; rotation++)
            {
                toCalculateSet = toCalculateSet.LeftNext;
              
                //得到每一种变化在每一列的第一个可以停止的位置,以后计算其它的,现在仅平移下降用不到高级技术.
                for (int i = -1; i < GameController.TheController.ColumnsCount - 1; i++)
                {
                    bool thefirstone = true; //是否是第一个找到的解，第一个解只需要一个路径就可以，通常不用判断是否可以到达
                    //（在最高行与当前已经重叠了的情况下除外）比如第二列有个长条，挡住了第一列位置。则第一列就无法放了
                    bool thelastisok = false; //上一行是否可行，如果可行，下一行不可行的时候 上一行是解，否则不是解。
                    List<WayPoint> theTempWay = new List<WayPoint>();            

                    for (int r = 0; r < GameController.TheController.RowsCount; r++)
                    {
                        //在上一行可以方，当前行不可以放的时候，就说明上一行是该停止的位置
                        if (insidePositionIsPermit(nowSituation, new XYPair(i, r), toCalculateSet))
                        {
                            if (!thelastisok) thelastisok = true;
                            continue;
                        }
                        //当上一行是可以的，则进行判断，
                        if (thelastisok)
                        {
                            thelastisok = false;//无论结果如何，想继续判断剩下的解就必须让上一行无效
                            //当是第二种以上的可能，或最高的位置已经可能阻碍横移了的情况下，必须判断是否有合理路径了。 
                            if (!thefirstone || theHeightOfNow <= 4)
                            {
                                if (!AStarMethod(nowSituation,new XYPair(i, r - 1), toCalculateSet, startAiPosition, inFunctionSet, out theTempWay))
                                {
                                    continue;
                                }
                                if (theTempWay.Count == 0) continue;                                    
                            }
                            if (theTempWay.Count == 0)
                                theTempWay.Add(new WayPoint(new XYPair(i, r - 1), toCalculateSet));
                            int tempValue,tempClearLinesCount;
                            List<int> insideCalcluateData = addSetToInsideCalcluateArray(nowSituation, new XYPair(i, r - 1), toCalculateSet, out tempClearLinesCount,out tempValue);
                           
                            //分数与当前几个最优解比较,如果可以进入这几个的备案,则替换原有方案
                            int findToChange ; 
                            for (findToChange = 0; findToChange < findBestWays.Count; findToChange++)
                            {
                                if (tempValue > findBestWays[findToChange].WayValue)
                                {
                                    break;     
                                }
                            }
                            if (findToChange < bestCount)
                            {
                                findBestWays.Insert(findToChange, new FindBestWay(tempValue, theTempWay, insideCalcluateData));                              
                            }
                            while (findBestWays.Count > bestCount)
                            {
                                findBestWays.RemoveAt(bestCount);
                            }                           
                            r++;//当前行是解的情况下，下一行一定不是解，直接跳过
                        }
                        //break; 这个break不加了以后，就可以继续向下判断，这样能把所有解都找到，但只要不是第一个，就要去检验是否可以到达，然后再计算
                        if (r == 0) break;//当r==0就停下了，说明这一列根本无法放，可能是－1列也可能是6，7，8这几列，图形左右超出。
                        thefirstone = false;
                    }
                }
            }
            return findBestWays;           
        }
       
        #endregion

        #region superspeed inside calculate

        /// <summary>
        /// 把界面层的元素转变成数组，数组的每一行代表实际的一行
        /// </summary>
        /// <param name="tempPad">当前的实际场景</param>
        /// <returns>当前逻辑存储的场景,递归后,均使用逻辑场景进行计算,不影响原实际值</returns>
        private List<int> insideCalcluateArray(PlayingModel tempPad)
        {
            List<int> toCalculatePoints = new List<int>();

            for (int r = 0; r < rowsCount; r++)
            {
                toCalculatePoints.Add(0);
                //下面是：相对标准的把数组转变成一个2进制数据的方法
                for (int i = 0; i < columnsCount; i++)
                {
                    toCalculatePoints[r] = toCalculatePoints[r] | (tempPad.AllPiece[i, r].State == 0 ? 1 << (columnsCount - 1 - i) : 0);
                }
            }
            return toCalculatePoints;
        }

        /// <summary>
        /// AI逻辑内 计算当前逻辑存储的场景的某一个位置是否可以放一个具体的块
        /// </summary>
        /// <param name="theArray">当前逻辑存储的场景</param>
        /// <param name="position">要放的位置的左上角坐标</param>
        /// <param name="toAddSet">要放的图形对象（这个没有再做优化，其实也可以做）</param>
        /// <returns>是否可以安放</returns>
        private bool insidePositionIsPermit(List<int> theArray, XYPair position, SetOfTetris toAddSet)
        {
            for (int i = 0; i < 4; i++)
            {
                try
                {
                    if (toAddSet.EachRow[i] == 0) continue;
                    if (toAddSet.EachRow[i] != 0 && position.Y < 0) return false;
                    if (i + position.Y >= rowsCount) return false;
                    //之所以用 0x7fc00fff 不用  0xffc00fff 是考虑当前是有符号整数，否则会报一个警告，大概意思是：符号位进行位运算不太好。
                    if (((theArray[i + position.Y] << 12 | 0x7fc00fff) & (toAddSet.EachRow[i] << (columnsCount + 8 - position.X))) != 0) return false;
                }
                catch //注意，把例外写在外面和写在里面 效率差了很多很多倍
                {
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// 把当前块加到当前逻辑存储的场景上
        /// </summary>
        /// <param name="theArray">当前逻辑存储的场景</param>
        /// <param name="position">模板位置</param>
        /// <param name="toAddSet">目标块类型</param>
        /// <returns></returns>
        private List<int> addSetToInsideCalcluateArray(List<int> theArray, XYPair position, SetOfTetris toAddSet,out int clearLines,out int getValues)
        {
            List<int> re = new List<int>();
            re.AddRange(theArray);

            for (int i = 0; i < 4; i++)
            {
                try
                {
                    if (i + position.Y >= rowsCount) continue;
                    //本来应该: theArray[i + position.Y] | toAddSet.EachRow[i] << (columnsCount - 4 - position.X),
                    //为了让toAddSet.EachRow[i]<< V 的V 不为负数 先均 <<4 然后再>>4. 
                    re[i + position.Y] = (theArray[i + position.Y] << 4 | toAddSet.EachRow[i] << (columnsCount - position.X)) >> 4;
                }
                catch { continue; }
            }
            getValues = evaluateFunction(ref re, out clearLines); //执行评价函数得到分数
            return re;
        }
        /// <summary>
        /// AI逻辑内部删除行操作
        /// </summary>
        /// <param name="theArray">当前逻辑存储的场景</param>
        /// <returns></returns>
        private int clearLinesToInsideCalcluateArray(ref List<int> theArray)
        {
            //从最后一行开始算，如果可以消除，则消除，
            int clearCount = 0;
            for (int i = rowsCount - 1; i >= 0; i--)
            {
                if (theArray[i] == fullLineCount)
                {
                    clearCount++;
                    theArray.RemoveAt(i);
                    i++;
                    theArray.Insert(0, 0);
                }
            }
            return clearCount;
        }
        #endregion
    }

    internal class MapPoint
    {
        XYPair position; //坐标点
        SetOfTetris theTetris;   //方块样式    
        int nowCost; //到达当前位置的最小距离
        int willCost; //到达终点的理论最小距离
        int horizontalTimes; //连续横向移动的次数
        MapPoint theComePoint; //来到当前点的上一个点

        #region 属性

        public int FullCost
        {
            get
            {
                return nowCost + willCost;
            }
        }
        public XYPair Position
        {
            get { return position; }
        }

        public SetOfTetris TheTetris
        {
            get { return theTetris; }
        }

        public int NowCost
        {
            get { return nowCost; }
            set { nowCost = value; }
        }

        public int WillCost
        {
            get { return willCost; }
        }

        public int HorizontalTimes
        {
            get { return horizontalTimes; }
        }

        internal MapPoint TheComePoint
        {
            get { return theComePoint; }
            set { theComePoint = value; }
        }

        #endregion

        public MapPoint(XYPair position, SetOfTetris theTetris, XYPair aimingPosition, SetOfTetris theAimTetris, int nowCost, int horizontalTimes, MapPoint theComePoint)
        {
            this.position = position;
            this.theTetris = theTetris;
            this.nowCost = nowCost;
            this.willCost = calculateWillCost(position, theTetris, aimingPosition, theAimTetris);
            this.horizontalTimes = horizontalTimes;
            this.theComePoint = theComePoint;
        }
        private int calculateWillCost(XYPair nowPosition, SetOfTetris theTetris, XYPair aimingPosition, SetOfTetris theAimTetris)
        {
            int tempCost = 0;
            //计算需要变形几次,一次cost 15;
            if (theTetris.CanChangeTimes == 1 || theTetris == theAimTetris)
                tempCost += 0;
            else if (theTetris.CanChangeTimes == 2 || theTetris.LeftNext == theAimTetris || theAimTetris.LeftNext == theTetris)
                tempCost += 15;
            else if (theTetris.CanChangeTimes == 4 && theTetris.LeftNext.LeftNext == theAimTetris)
                tempCost += 30;
            else
            {
                return 999999;
            }
            //计算高度差,一个高度差cost 10;
            if (nowPosition.Y > aimingPosition.Y) return 999999;
            tempCost += (aimingPosition.Y - nowPosition.Y) * 10;
            //计算横向差,一个横向差用其高度*5+10 如横向的长条,就是15,竖条就是30
            //离目标横向越近,横向移动的代价越大;20的时候横向为10 19的时候横向为15 18 为20 height>=20
            int tempHeight =  nowPosition.Y - aimingPosition.Y;
            tempCost += Math.Abs(nowPosition.X - aimingPosition.X) * (5 * theAimTetris.Height + tempHeight >= 18 ? 0 : 7 * (18 - tempHeight));
            return tempCost;
        }

        public override string ToString()
        {
            return position.ToString() + "$" + theTetris.ToString();
        }
    }

    internal class FindBestWay
    {

        public FindBestWay(int wayValue, List<WayPoint> theWay, List<int> theSituation)
        {
            this.wayValue = wayValue;
            this.theWay = theWay;
            this.theSituation = theSituation;
        }
        int wayValue;

        public int WayValue
        {
            get { return wayValue; }
            set { wayValue = value; }
        }
        List<WayPoint> theWay;

        public List<WayPoint> TheWay
        {
            get { return theWay; }
            set { theWay = value; }
        }
        List<int> theSituation;

        public List<int> TheSituation
        {
            get { return theSituation; }
            set { theSituation = value; }
        }
    }
}
