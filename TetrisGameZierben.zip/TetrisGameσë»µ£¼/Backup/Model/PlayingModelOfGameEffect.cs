﻿using System;
using System.Collections.Generic;
using System.Text;
using ZierbensTetris.DataObj;
using System.Drawing;

namespace ZierbensTetris.Model
{
    internal partial class PlayingModel
    {
        #region //gameover Effect
        //1.简单模式，从顶到底，一行行用背景填充，然后一行行的清空，然后让GAMEOVER字样一个一个的连续下降，降出屏幕则不显示 
        //gameover用的点阵是8*8 所以需要在两边加个亮边。
        
        static List<int[]> gameOverDownLetter = new List<int[]> (); // -1 边 0 空 1 实；

        internal  static void InitGameOverDownLetter()
        {
            if (gameOverDownLetter.Count==0)
            {
                char[] sGameOverArray = "GAMEOVER!PLAY AGAIN PLEASE!".ToCharArray();
                for (int i = 0; i < sGameOverArray.Length *9; i++)
                {
                    gameOverDownLetter.Add(new int[10]);
                    gameOverDownLetter[i][0] = -1;
                    gameOverDownLetter[i][9] = -1;
                    for (int r = 1; r < 9; r++)
                    {
                        gameOverDownLetter[i][r] = (LetterLattice.Instance.GetPointOfXYIsFilled(sGameOverArray[i / 9], r - 1, i % 9) ? 1 : 0);
                    }
                }
            }
        }
        static int sleeptimes = 0;
        internal void GameOverShowNextStep(PlayingModel theModel)
        {
            if (theModel.GameOverEffectState == 0)
            {
                if (theModel.GameOverStep >= theModel.RowsCount)
                {
                    theModel.GameOverEffectState = 1;
                    theModel.GameOverStep = 0;
                }
                else
                {
                    for (int i = 0; i < theModel.ColumnsCount; i++)
                    {
                        theModel.AllPiece[i, theModel.GameOverStep].State = 0;
                        theModel.AllPiece[i, theModel.GameOverStep].TheColor = Color.Gray;
                    }
                    theModel.GameOverStep++;
                } 
            }
            if (theModel.GameOverEffectState == 1)
            {
                if (theModel.GameOverStep >= theModel.RowsCount)
                {
                    theModel.GameOverEffectState = 2;
                    theModel.GameOverStep = 0;
                }
                else
                {
                    for (int i = 0; i < theModel.ColumnsCount; i++)
                    {
                        theModel.AllPiece[i, theModel.RowsCount - theModel.GameOverStep - 1].State = -1;
                        theModel.AllPiece[i, theModel.RowsCount - theModel.GameOverStep - 1].TheColor = Color.Gray;
                    }
                    theModel.GameOverStep++;
                }
               
            }
            if (theModel.GameOverEffectState == 2)
            {
                sleeptimes++;
                if (sleeptimes > 2) sleeptimes = 0;
                else return;
                theModel.AllLinesMove(1, theModel.RowsCount - 1, -1);
                for (int i = 0; i < theModel.ColumnsCount; i++)
                {
                    switch (gameOverDownLetter[(theModel.GameOverStep) % gameOverDownLetter.Count][i])
                    {
                        case 1:
                            theModel.AllPiece[i, theModel.RowsCount - 1].State = 0;
                            theModel.AllPiece[i, theModel.RowsCount - 1].TheColor = Color.DarkGray;
                            break;
                        case 0:
                            theModel.AllPiece[i, theModel.RowsCount - 1].State = -1;
                            theModel.AllPiece[i, theModel.RowsCount - 1].TheColor = Color.White;
                            break;
                        case -1:
                            theModel.AllPiece[i, theModel.RowsCount - 1].State = 0;
                            theModel.AllPiece[i, theModel.RowsCount - 1].TheColor = (theModel.GameOverStep % 2 == 0 ? Color.Gray : Color.DarkGray);
                            break;
                    }
                }
                theModel.GameOverStep++;
            }
        }
        #endregion


        //public delegate bool TestF<T, R>(T testTarget, R e) where R : XYPair;
        //public delegate bool TestF<R>(object testTarget, R e) where R : XYPair;
        //public TestF<XYPair> p;
        //public TestF<PlayingModel, XYPair> p2;
    }
}
