﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Drawing;

namespace ZierbensTetris.DataObj
{
    public class PieceOfPad:ICloneable
    {

        private Color theColor = Color.White;//默认白色，就是相当于透明背景

        /// <summary>
        /// 当前块的颜色
        /// </summary>
        public Color TheColor
        {
            get { return theColor; }
            set { theColor = value; }
        }
        private int state = -1;  
       
        /// <summary>
        /// -1,没有东西 0 正常，1，正要消失，2，消失中，3，消失大半，4，消失完毕，5，下移1/4，
        /// 6下移一半，7下移3/4，8，左晃，9，右晃，10，闪烁1，11，闪烁2
        /// 暂时只允许 -1,0状态即可。 以后再扩充
        /// </summary>
        public int State
        {
            get { return state; }
            set { state = value; }
        }


        #region ICloneable 成员

        public object Clone()
        {
            PieceOfPad toCloneOne =  new PieceOfPad();
            toCloneOne.State = this.state;
            toCloneOne.TheColor = this.theColor;
            return toCloneOne;
        }

        #endregion
    }
}
