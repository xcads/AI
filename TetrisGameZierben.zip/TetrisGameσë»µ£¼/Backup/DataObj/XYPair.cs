﻿using System;
using System.Collections.Generic;
////using System.Linq;
using System.Text;

namespace ZierbensTetris.DataObj
{
    public class XYPair:ICloneable
    {
        public int X;
        public int Y;

        public XYPair(int x, int y)
        {
            X = x;
            Y = y;
        }

        public XYPair Add(XYPair another)
        {
            return new XYPair(X + another.X, Y + another.Y);
        }

        public override bool Equals(object obj)
        {            
            return (obj.GetType().Equals (this.GetType ()) &&  this.X == ((XYPair)obj).X && this.Y == ((XYPair)obj).Y);
        }
        public override int GetHashCode()
        {
            return X * 1235849 + Y * 4391283;
        }
        public override string ToString()
        {
            return "X:" + X.ToString() + " - Y:" + Y.ToString();
        }
        #region ICloneable 成员

        public object Clone()
        {
            return new XYPair(this.X, this.Y);
        }

        #endregion
    }
}
