﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Drawing;

namespace ZierbensTetris.DataObj
{
    /// <summary>
    /// 一个游戏方块，比如长条或者拐弯的
    /// </summary>
    public class SetOfTetris
    {
        private List<XYPair> positionList = new List<XYPair>();
        private List<int> eachRow = new List<int>();
        private SetOfTetris leftNext = null;
        private SetOfTetris rightNext = null;
        private bool canPassThrow = false; 
        private int leftCanMoveWhenErr = 0;       
        private int rightCanMoveWhenErr = 0;
        private Color defaultColor = Color.Blue;
        private int valuation = 1000;
        private int valuationWithSuper = 1000;
        private string name;
        private int changeTimes = 1;
        private AllTypeOfSets theType;
        private int startValueLine = 0;
       
        public override string ToString()
        {
            return name + "变化了" + changeTimes.ToString() + "次";
        }
        /// <summary>
        /// 把初始化好的positionList用eachRow的方式翻译，暂时只允许4行4列，最大的值为15，最小的为0
        /// </summary>
        private void transToListRowFromListPoint()
        {
            eachRow.Clear();
            for (int i = 0; i < 4; i++) eachRow.Add(0);
            foreach (XYPair p in positionList)
            {
                try
                {
                    eachRow[p.Y] = eachRow[p.Y] | (1 << (3 - p.X));
                }
                catch { continue; }//出异常只能是出现了超过4行4列的情况
            }
            
        }
        private SetOfTetris(AllTypeOfSets theType,string name, List<XYPair> positionList, bool canPassThrow, int leftCanMoveWhenErr, int rightCanMoveWhenErr, 
            Color defaultColor, int valuation ,int valuationWithSuper,int changeTimes)
        {
            this.theType = theType;
            //注意 本构造函数依然没有完全初始化,由于还有两个对象leftNext.rightNext并没有初始化,好在这个构造是内部的,不允许外部构造.
            this.name = name;
            //这里只能重新clone一份,否则可能使这个信息丢失掉
            for (int i = 0; i < positionList.Count; i++)
            {
                this.positionList.Add((XYPair)(positionList[i].Clone()));
            }
            this.canPassThrow  = canPassThrow;
            this.leftCanMoveWhenErr = leftCanMoveWhenErr;
            this.rightCanMoveWhenErr = rightCanMoveWhenErr;
            this.defaultColor = defaultColor;
            this.valuation = valuation;
            this.valuationWithSuper = valuationWithSuper;
            this.changeTimes = changeTimes;
            transToListRowFromListPoint();
            if (eachRow[0] == 0) startValueLine = 1;
        }
        #region 属性区域

        /// <summary>
        /// 所有有效元素的位置,通常规则块均为4个,而不规则块就未必了
        /// </summary>
        public List<XYPair> PositionList
        {
            get { return positionList; }
            set { positionList = value; }
        }

        public AllTypeOfSets TheType
        {
            get { return theType; }
            set { theType = value; }
        }
        public List<int> EachRow
        {
            get { return eachRow; }
            set { eachRow = value; }
        }

        /// <summary>
        /// 左转 --> 逆时针转动的下一个 方块样式
        /// </summary>
        public SetOfTetris LeftNext
        {
            get { return leftNext; }
            set { leftNext = value; }
        }       

        /// <summary>
        /// 右转 --> 顺时针转动的下一个 方块样式
        /// </summary>
        public SetOfTetris RightNext
        {
            get { return rightNext; }
            set { rightNext = value; }
        }

        /// <summary>
        /// 是否可以穿越
        /// 如果可以,则每次检验是否应该停止时,需要依次向下检验 当前位置不能停,则往下检验,一直到出去为止.
        /// 只要成功,则瞬移过去.通常仅允许小点(单个小格的那个)可以穿越,但是也可以初始化的时候设置.甚至全部可以穿越.
        /// </summary>
        public bool CanPassThrow
        {
            get { return canPassThrow; }
            set { canPassThrow = value; }
        }

        /// <summary>
        /// 如果旋转后失败,可疑往左移动几个单元格...
        /// 比如竖条在右边缘变横,可能伸出右屏幕外,则可以往左走几个格,
        /// </summary>
        public int LeftCanMoveWhenErr
        {
            get { return leftCanMoveWhenErr; }
            set { leftCanMoveWhenErr = value; }
        }

        /// <summary>
        /// 如果旋转后失败,可疑往右移动几个单元格...
        /// 比如竖条在左边缘变横,可能伸出左屏幕外,则可以往右走几个格,
        /// </summary>
        public int RightCanMoveWhenErr
        {
            get { return rightCanMoveWhenErr; }
            set { rightCanMoveWhenErr = value; }
        }      

        /// <summary>
        /// 权值 加权后随机 效果更好
        /// </summary>
        public int Valuation
        {
            get { return valuation; }
            set { valuation = value; }
        }
        /// <summary>
        /// 加上超级方块后的权值,由于所有方块都加上了,可能权值发生一些变化效果会更好,默认并不使用.
        /// </summary>
        public int ValuationWithSuper
        {
            get { return valuationWithSuper; }
            set { valuationWithSuper = value; }
        }
        /// <summary>
        /// 默认颜色
        /// </summary>
        public Color DefaultColor
        {
            get { return defaultColor; }
            set { defaultColor = value; }
        }
        /// <summary>
        /// 当前块的名称
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Height
        {
            get
            {
                int re = 0;
                foreach (int oneRow in EachRow)
                {
                    if (oneRow != 0) re++;
                }
                return re;
            }
        }
        public int CanChangeTimes
        {
            get
            {
                if (this.leftNext == this) return 1;
                else if (this.leftNext.leftNext == this) return 2;
                else return 4;
            }
        }
        #endregion

        public bool TurnLeft(out SetOfTetris theNewSet)
        {
            return turn(leftNext, out theNewSet);
        }
        public bool TurnRight(out SetOfTetris theNewSet)
        {
            return turn(rightNext, out theNewSet);
        }

        private bool turn(SetOfTetris nextSet, out SetOfTetris theNewSet)
        {
            theNewSet = this;

            return true;
            //当前对象可以运动
            //当前对象移动到左的对象不为空

            //移动到左的对象的各位置与当前场景均为吻合的，即可以移动的，
            //如果不能移动，但是当前位置左移 LeftCanMoveWhenErr以内 可以移动，则同样允许移动，
            //如果不能移动，但是当前位置右移 RightCanMoveWhenErr以内 可以移动，则同样允许移动，

            //如果依然不能移动则返回，可以移动则返回另一个对象
        }

        public override int GetHashCode()
        {
            return  ((int)theType)<<2 | changeTimes; //
        }

        /// <summary>
        /// 表示从第几行开始有值,比如长条的横过来的模样,从第二行有值,这个值如果是1表示是第二行,起始位置不应该是0,而是-1
        /// </summary>
        public int StartValueLine
        {
            get { return startValueLine; }
            set { startValueLine = value; }
        }
        #region 所有的各种形式初始化
        private static Dictionary<AllTypeOfSets, List<SetOfTetris>> dicAll = new Dictionary<AllTypeOfSets, List<SetOfTetris>>();

        public static Dictionary<AllTypeOfSets, List<SetOfTetris>> DicAll
        {
            get {return SetOfTetris.dicAll; }            
        }
       
        /// <summary>
        ///  一次性填充一个元素及其所有转动可得的元素
        /// </summary>
        /// <param name="theTypeOfSets">方块的种类</param>
        /// <param name="allPoint">每一个可视元素的位置,至少一个,至多不限,将来可以多于4*4</param>
        /// <param name="canPassThrow">是否可以穿越</param>
        /// <param name="sideLength">边长:由于转动一圈后均为正方形,可能是1*1,2*2,3*3,4*4等,注意1,2的情况起始点按照1,0算不是00</param>
        /// <param name="theColor">颜色,能互相旋转的颜色必须一致</param>
        /// <param name="valuation">权值</param>
        /// <param name="valuationWithSuper">当包含超级快的时候的权值</param>
        /// <param name="name">名称,一个块的各种变形的名称时一致的</param>
        private static void InitOneSets(AllTypeOfSets theTypeOfSets, List<XYPair> allPoint,bool canPassThrow,
            int sideLength, Color theColor, int valuation, int valuationWithSuper, string name,int maxRotationCount)
        {
            int startx = (sideLength < 3 ? 1 : 0); 
            List<SetOfTetris> theSetsGroup =  new List<SetOfTetris>();     
            int minx = 4,maxx=0; 
            
            List<XYPair> lastAll = new List<XYPair>();
            for (int i = 0; i < allPoint.Count; i++)
            {
                lastAll.Add((XYPair)allPoint[i].Clone());
                if(allPoint[i].X < minx) minx= allPoint[i].X;
                if(allPoint[i].X > maxx ) maxx = allPoint[i].X;
            }
            int changeTimes = 0;
            bool needGoOn;
            do
            {
                changeTimes++;
                SetOfTetris theFirstOne = new SetOfTetris(theTypeOfSets, name, lastAll, canPassThrow, 2, 1, theColor, valuation, valuationWithSuper, changeTimes);
                theSetsGroup.Add(theFirstOne);
                if (theSetsGroup.Count >= maxRotationCount)
                    break;
                needGoOn = false;
                List<XYPair> tempAll = new List<XYPair>(); 
                for (int i = 0; i < allPoint.Count; i++)
                {
                    //左转, 如(3,1) 左转是 (1,0) 再左转 (0,2) 再左转 (2,3) 实际 x2=y1,y2=3-x1 
                    //而如果x都加上startx 则表示为 x2= y1+startx,y2=sideLength - 1 - x1 + startx
                    tempAll.Add(new XYPair(lastAll[i].Y + startx, sideLength - 1 - lastAll[i].X + startx));                    
                }

                lastAll.Clear();
                minx = 4;
                maxx = 0;               
                for (int i = 0; i < allPoint.Count; i++)
                {
                    //判断是否需要再次循环添加,当再次旋转的结果与传入参数一致,说明转了一圈了,
                    if (!needGoOn && !allPoint.Contains(tempAll[i])) needGoOn = true;
                    //重新复制lastAll
                    lastAll.Add((XYPair)tempAll[i].Clone());
                    //判断下一个左右允许转动后往外移动的量;
                    if (tempAll[i].X < minx) minx = tempAll[i].X;
                    if (tempAll[i].X > maxx) maxx = tempAll[i].X;
                }
                //如果跟开始的一样,则不要再添加了                  
            }
            while (needGoOn);

            //为所有的转动块赋值左转和右转的next
            for (int i = 0; i < theSetsGroup.Count; i++)
            {
                //为了避免负数的余数有问题,求余之前保证为正
                theSetsGroup[i].LeftNext = theSetsGroup[(i + 1) % theSetsGroup.Count];
                theSetsGroup[i].RightNext = theSetsGroup[(i + theSetsGroup.Count - 1) % theSetsGroup.Count];
                theSetsGroup[i].Valuation = valuation;
                theSetsGroup[i].ValuationWithSuper = valuationWithSuper;
            }
            dicAll.Add(theTypeOfSets, theSetsGroup);
        }
        public static void InitCommonSets()
        {
            if (!dicAll.ContainsKey(AllTypeOfSets.FOURLINE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 1)); //
                allPoint.Add(new XYPair(1, 1)); //[][][][]
                allPoint.Add(new XYPair(2, 1)); //
                allPoint.Add(new XYPair(3, 1)); //

                InitOneSets(AllTypeOfSets.FOURLINE, allPoint, false, 4, Color.Orange, 1000, 4000, "4节长条",2);  
            }
            
            if (!dicAll.ContainsKey(AllTypeOfSets.SQUARE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //  [][]
                allPoint.Add(new XYPair(1, 1)); //  [][]
                allPoint.Add(new XYPair(2, 0)); // 
                allPoint.Add(new XYPair(2, 1)); //  
                InitOneSets(AllTypeOfSets.SQUARE, allPoint, false, 2, Color.DarkBlue, 1000, 4000, "正方形",1);                   
            }
            
            if (!dicAll.ContainsKey(AllTypeOfSets.ZSHAPE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 0)); //[][]
                allPoint.Add(new XYPair(1, 0)); //  [][]
                allPoint.Add(new XYPair(1, 1)); //    
                allPoint.Add(new XYPair(2, 1)); //   
                InitOneSets(AllTypeOfSets.ZSHAPE, allPoint, false, 3, Color.DarkGreen, 1000, 4000, "Z型",2);        
            }
            
            if (!dicAll.ContainsKey(AllTypeOfSets.MIRRORZSHAPE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 0)); //[]
                allPoint.Add(new XYPair(0, 1)); //[][]
                allPoint.Add(new XYPair(1, 1)); //  [] 
                allPoint.Add(new XYPair(1, 2)); // 
                InitOneSets(AllTypeOfSets.MIRRORZSHAPE, allPoint, false, 3, Color.DarkSeaGreen, 1000, 4000, "逆Z型",2);       
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.HILLSHARP))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 1)); //  []
                allPoint.Add(new XYPair(1, 0)); //[][][]
                allPoint.Add(new XYPair(1, 1)); //   
                allPoint.Add(new XYPair(2, 1)); //  
                InitOneSets(AllTypeOfSets.HILLSHARP, allPoint, false, 3, Color.Maroon, 1000, 4000, "山型",4);  
            }
          
            if (!dicAll.ContainsKey(AllTypeOfSets.LSHAPE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //[]
                allPoint.Add(new XYPair(1, 1)); //[]
                allPoint.Add(new XYPair(1, 2)); //[][]   
                allPoint.Add(new XYPair(2, 2)); // 
                InitOneSets(AllTypeOfSets.LSHAPE, allPoint, false, 3, Color.DarkViolet, 1000, 4000, "L型",4);  
      
            }

            if (!dicAll.ContainsKey(AllTypeOfSets.MIRRORLSHAPE))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //    []
                allPoint.Add(new XYPair(1, 1)); //    []
                allPoint.Add(new XYPair(1, 2)); //  [][] 
                allPoint.Add(new XYPair(0, 2)); //  
                InitOneSets(AllTypeOfSets.MIRRORLSHAPE, allPoint, false, 3, Color.DodgerBlue, 1000, 4000, "逆L型",4);   
                 
            }       
         

        }

        public static void InitSuperSets()
        {
            if (!dicAll.ContainsKey(AllTypeOfSets.GREATPOINT))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //    [] 
                InitOneSets(AllTypeOfSets.GREATPOINT, allPoint, true, 1, Color.Gold, 0, 2000, "小点儿", 1);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.PLUS))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 1)); //  []
                allPoint.Add(new XYPair(1, 0)); //[][][]
                allPoint.Add(new XYPair(1, 1)); //  [] 
                allPoint.Add(new XYPair(2, 1)); //  
                allPoint.Add(new XYPair(1, 2)); //  
                InitOneSets(AllTypeOfSets.PLUS, allPoint, false, 3, Color.OrangeRed, 0, 700, "加号", 1);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.BIGZ))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //[][]
                allPoint.Add(new XYPair(1, 2)); //  [] 
                allPoint.Add(new XYPair(1, 1)); //  [][] 
                allPoint.Add(new XYPair(2, 2)); //  
                allPoint.Add(new XYPair(0, 0)); //  
                InitOneSets(AllTypeOfSets.BIGZ, allPoint, false, 3, Color.Chocolate, 0, 800, "大Z型", 2);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.BIGZMIRROR))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //  [][]
                allPoint.Add(new XYPair(1, 2)); //  [] 
                allPoint.Add(new XYPair(1, 1)); //[][] 
                allPoint.Add(new XYPair(0, 2)); //  
                allPoint.Add(new XYPair(2, 0)); //  
                InitOneSets(AllTypeOfSets.BIGZMIRROR, allPoint, false, 3, Color.BlueViolet, 0, 800, "逆大Z型", 2);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.BIGH))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 0)); //[]  []
                allPoint.Add(new XYPair(0, 1)); //[][][] 
                allPoint.Add(new XYPair(0, 2)); //[]  []
                allPoint.Add(new XYPair(1, 1)); //  
                allPoint.Add(new XYPair(2, 0)); //  
                allPoint.Add(new XYPair(2, 1)); //  
                allPoint.Add(new XYPair(2, 2)); //  
                InitOneSets(AllTypeOfSets.BIGH, allPoint, false, 3, Color.SteelBlue, 0, 700, "大H型", 2);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.TWOPOINTLINEHORIZONTAL))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //  [][]
                allPoint.Add(new XYPair(2, 0)); //
                InitOneSets(AllTypeOfSets.TWOPOINTLINEHORIZONTAL, allPoint, false, 2, Color.CornflowerBlue, 0, 1500, "两点条", 2);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.THREEPOINTLINEHORIZONTAL))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(0, 0)); //[][][]
                allPoint.Add(new XYPair(1, 0)); //
                allPoint.Add(new XYPair(2, 0)); //
                InitOneSets(AllTypeOfSets.THREEPOINTLINEHORIZONTAL, allPoint, false, 3, Color.Indigo, 0, 1500, "三点条", 2);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.CORNER))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //  [][]
                allPoint.Add(new XYPair(2, 0)); //  []
                allPoint.Add(new XYPair(1, 1)); //
                InitOneSets(AllTypeOfSets.CORNER, allPoint, false, 2, Color.ForestGreen, 0, 1500, "拐角", 4);
            }
            if (!dicAll.ContainsKey(AllTypeOfSets.BIGT))
            {
                List<XYPair> allPoint = new List<XYPair>();
                allPoint.Add(new XYPair(1, 0)); //[][][]
                allPoint.Add(new XYPair(2, 0)); //  []
                allPoint.Add(new XYPair(1, 1)); //  []
                allPoint.Add(new XYPair(0, 0)); //   
                allPoint.Add(new XYPair(1, 2)); //   
                InitOneSets(AllTypeOfSets.BIGT, allPoint, false, 3, Color.ForestGreen, 0, 800, "大T", 4);
            }  
        }

        #endregion
    }

    /// <summary>
    /// 所有种类的方块，值不要超过64，这样计算hash的时候可以用8位把所有的方块记录下来。( 64《2 | 转动次数) 在256以内。
    /// </summary>
    public enum AllTypeOfSets
    {
        FOURLINE = 1, 
        SQUARE = 2,
        ZSHAPE  = 3, 
        MIRRORZSHAPE  = 4, 
        HILLSHARP = 5,    
        LSHAPE = 6, 
        MIRRORLSHAPE = 7, 
        /////up is common sets,down is super sets//////////
        GREATPOINT = 10,
        PLUS = 11,
        BIGZ = 12,
        BIGZMIRROR = 13, 
        BIGH = 14,  
        TWOPOINTLINEHORIZONTAL = 15, 
        THREEPOINTLINEHORIZONTAL = 16, 
        CORNER = 17, 
        BIGT = 18,
    }
}
