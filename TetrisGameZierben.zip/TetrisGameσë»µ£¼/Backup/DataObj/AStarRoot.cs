﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZierbensTetris.DataObj
{
    public struct AStarRoot
    {
        public int X;
        public int Y; 
        public int ThisHash;
        public int StepCount;
        public SetOfTetris TheSet; 
        public List<AStarRoot> allComeRoot; //所有可以到达这步的点
        public AStarRoot(int x,int y,SetOfTetris theSet,int stepCount )
        {
            X = x;
            Y = y; 
            // 由于X可能小于0 ，给它加上4再位移就ok了
            ThisHash = (X + 4) << 16 | Y << 8 | theSet.GetHashCode(); 
            TheSet = theSet;
            StepCount = stepCount;
            allComeRoot = new List<AStarRoot>();
        } 
    }
}
