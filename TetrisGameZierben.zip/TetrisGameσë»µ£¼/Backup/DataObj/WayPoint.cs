﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZierbensTetris.DataObj
{
    /// <summary>
    /// 路点:元素有 目的坐标,移动的块形状 
    /// 移动前需要先调整形状
    /// 
    /// 如果希望移动后调整形状的,必须写两个路点,第一套是移动到位置不变形状,第二个路点是变形状,目标地点相同.
    /// 
    /// </summary>
    public struct WayPoint
    {
        public XYPair TheAimPoint; 
        public SetOfTetris TheAimSet;
        public int HashOfSet;
        public WayPoint(XYPair theAimPoint, SetOfTetris theAimSet)
        {
            TheAimPoint = theAimPoint;
            this.TheAimSet = theAimSet;
            HashOfSet = theAimPoint.GetHashCode(); 
        }
        public override string ToString()
        {
            return TheAimPoint.ToString() + "$" + TheAimSet.ToString();
        }
    }
}
