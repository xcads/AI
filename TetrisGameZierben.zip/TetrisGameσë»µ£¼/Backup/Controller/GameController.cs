﻿using System;
using System.Collections.Generic; 
using System.Text;
using ZierbensTetris.Model;
using ZierbensTetris.DataObj;
using System.Drawing;

namespace ZierbensTetris.Controller
{
    /// <summary>
    /// 控制处理，所有的具体操作均在PlayingModel中处理
    /// 仅保留一个controller，所以左右两个人，或者以后可能多于2个人的情况均可以
    /// </summary>
    public partial class GameController
    {
        int rowsCount;
        int columnsCount;
    
        public static Random RAND = new Random();
 
        private List<PlayingModel> allModel = new List<PlayingModel>();   
        private int theStartLevel = 0;//max is 9  
        int theMaxScore;

        #region 主动通知界面层的委托
        public delegate void changeValue(int playerIndex,int value);
        public changeValue ChangeScore; 
        public changeValue ChangeLevel;
        public changeValue ChangeClearLines;
        public changeValue ChangeToActLineCount;
        public delegate void changeDropMode(int playerIndex,bool downToEndMode);
        public changeDropMode ChangeDropMode;

        public delegate void callOuter(int playerIndex);
        public callOuter TellChangeSet;
        #endregion


        internal PlayingModel GetTheModel(int index)
        {
            if (index >= 0 && allModel.Count > index) return allModel[index];
            throw new Exception("Cannot find the PlayingModel of Index =" + index.ToString());
        }   

        #region 主动跟踪所有Pad的变化 
        /// <summary>
        /// 给前台设置最新的分数、速度等信息
        /// </summary>
        private void setValueToForm(int index)
        {
            if (ChangeScore != null) ChangeScore(index, allModel[index].TheScore);
            //每一万分上升一个等级
            int newLevel = (allModel[index].TheScore / 10000 + theStartLevel) % 10;
            if (allModel[index].TheLevel != newLevel)
            {
                GameControllerOfSound.MakeSound(6);
                allModel[index].TheLevel = newLevel;
                if (ChangeLevel != null) ChangeLevel(index, allModel[index].TheLevel);
            }            
            if (ChangeClearLines != null) ChangeClearLines(index, allModel[index].AllClearLines);
        }

        private void setNextSetToForm(int index)
        {
            if (TellChangeSet != null) TellChangeSet(index);
        }
        private void setDownToEndModeToForm(int index)
        {
            if (ChangeDropMode != null) ChangeDropMode(index,allModel[index].DownToEndMode);            
        }
        
        
        #endregion

        #region 属性区域
        /// <summary>
        /// 当前游戏区域有多少横行
        /// </summary>
        public int RowsCount
        {
            get { return rowsCount; }
            set { rowsCount = value; }
        }
        /// <summary>
        /// 当前游戏区域有多少竖列
        /// </summary>
        public int ColumnsCount
        {
            get { return columnsCount; }
            set { columnsCount = value; }
        }

        public int TheMaxScore
        {
            get { return theMaxScore; }
            set { theMaxScore = value; }
        }
 
        public int PlayerCount
        {
            get { return allModel.Count ; } 
        }
       
        public bool GetDownToEndMode(int index)
        {
            return GetTheModel(index).DownToEndMode;
        }
        public void SetDownToEndMode(int index, bool downToEndMode)
        {
            GetTheModel(index).DownToEndMode = downToEndMode;
        }
        
        public int GetToActLineCount(int index)
        {
            return GetTheModel(index).ToActLineCount;
        }
        public SetOfTetris GetTheNextSet(int index)
        {
            return GetTheModel(index).TheNextSet;
        }
        public bool GetPassThrowMode(int index)
        {
            return GetTheModel(index).PassThrowMode;
        }
        public void SetPassThrowMode(int index, bool passThrowMode)
        {
            GetTheModel(index).PassThrowMode = passThrowMode;
        }
        public SetOfTetris GetTheMovingSet(int index)
        {
            return GetTheModel(index).TheMovingSet;
        }
        #endregion

        #region 游戏过程操作

        public bool SomeOneIsOver()
        {
            //从第一个开始一直到最后一个。。。
            for (int i = 0; i < allModel.Count; i++)
            {
                if (allModel[i].GameOver) return true;
            }
            return false;
        }
        public bool AllPlayIsOver()
        {
            //从第一个开始一直到最后一个。。。
            for (int i = 0; i < allModel.Count; i++)
            {
                if (!allModel[i].GameOver) return false;
            }
            return true;
        }
        /// <summary>
        /// 玩下一步，不管是人还是电脑，由timer触发的移动均进入到这里
        /// return false gameover
        /// </summary>
        /// <returns></returns>
        public void PlayNextStep()
        {
            //从第一个开始一直到最后一个。。。
            for (int i = 0; i < allModel.Count; i++)
            {
                allModel[i].PlayNextStep();
            }
        }

        /// <summary>
        /// 左移
        /// </summary>
        /// <returns></returns>
        public bool MoveLeft(int index)
        {
            return allModel[index].MoveLeft();           
        }
        /// <summary>
        /// 右移
        /// </summary>
        /// <returns></returns>
        public bool MoveRight(int index)
        {
            return allModel[index].MoveRight();           
        }

        /// <summary>
        /// 快速下降
        /// </summary>
        /// <returns></returns>
        public void FasterDrop(int index)
        {
            allModel[index].FasterDrop();       
        }

        public void Fight(int index,int aimIndex)
        {
            allModel[index].Fight(GetTheModel(aimIndex));
            allModel[index].OneScoreChanged(index);
        }
        public void gameover(int index)
        {
            allModel[index].gameover();
        } 

        /// <summary>
        /// 转动
        /// </summary>
        /// <returns></returns>
        public bool Turn(int index)
        {
            return allModel[index].Turn();
        }

        #endregion

        #region 初始化过程

        private static GameController theController = new GameController();

        public static GameController TheController
        {
            get { return GameController.theController; } 
        }
 
        private GameController()
        { 
            PlayingModel.InitGameOverDownLetter();
        }

        /// <summary>
        /// 重新初始化
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public void InitEnvironment(int rowsCount,int columnsCount )
        { 
            this.rowsCount = rowsCount;
            this.columnsCount = columnsCount;
        }
       
        /// <summary>
        /// 初始化游戏
        /// </summary>
        /// <param name="speed">下落速度1~10</param>
        /// <param name="hardLevel">开始难度1~rowCount-5 必须留出5行</param>
        /// <param name="useSuperSets">是否实用超级组，比如十字花Z型拐弯等不规则的形状</param>
        public void StartGame(int playerCount,List<int> whoIsComputer,int speed, int hardLevel, bool useSuperSets)
        {            
            PlayingModel.InitPlayingModel(useSuperSets);
           
            theStartLevel = speed;
            allModel.Clear();
            for (int i = 0; i < playerCount; i++)
            {
                PlayingModel tempPlayingModel = new PlayingModel(rowsCount,columnsCount);
                tempPlayingModel.Index = i;
                allModel.Add(tempPlayingModel);
                tempPlayingModel.OneScoreChanged = new PlayingModel.SomeThingChanged(setValueToForm);
                tempPlayingModel.NextItemChanged = new PlayingModel.SomeThingChanged(setNextSetToForm);
                tempPlayingModel.DropDownModeChanged = new PlayingModel.SomeThingChanged(setDownToEndModeToForm);
                setDownToEndModeToForm(i);
                if (whoIsComputer.Contains(i)) tempPlayingModel.IsComputer = true; 
                tempPlayingModel.StartGame(speed, hardLevel);
            }
            for (int i = 0; i < playerCount; i++)
            {
                List<PlayingModel> fighters = new List<PlayingModel>();
                for (int r = 0; r < playerCount; r++)
                {
                    if (i != r) fighters.Add(allModel[r]);
                }
                allModel[i].Fighters = fighters;
            }
        }     
       
        #endregion
    }
}
