﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;

namespace ZierbensTetris.Controller
{
    public static class GameControllerOfSound
    {   
        [DllImport("winmm.dll")]
        public static extern int waveOutGetVolume(IntPtr hwo, out uint dwVolume);

        [DllImport("winmm.dll")]
        public static extern int waveOutSetVolume(IntPtr hwo, uint dwVolume);

        static List<SoundPlayer> allSound = new List<SoundPlayer>();
        /// <summary>
        /// 背景声效的播放,这个小程序就不做enum了 直接用type实现
        /// 0:落地,1:1行,2:2行,3:3行,4:4行,5:攻击对方,6:升级
        /// </summary>
        /// <param name="type"></param>
        public static void MakeSound(int type)
        {  
           if(type>=0 && type < 7) allSound[type].Play(); 
        }
        public static void initSound()
        {
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.put));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.oneline));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.twolines));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.threelines));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.fourlines));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.fightother));
            allSound.Add(new SoundPlayer(ZierbensTetris.Properties.Resources.levelup));

        }

        public static int GetVolume()
        {
            uint CurrVol; 
            waveOutGetVolume(IntPtr.Zero, out CurrVol); 
            ushort CalcVol = (ushort)(CurrVol & 0x0000ffff); 
            return (int)(CalcVol / (ushort.MaxValue / 10)); 
        }

        /// <summary>
        /// 设置音量
        /// </summary>
        /// <param name="step">0~10</param>
        public static void SetVolume(int step)
        {
            if (step < 0) step = 0;
            else if (step > 10) step = 10;
            // Calculate the volume that's being set
            int NewVolume = ((ushort.MaxValue / 10) * step);
            // Set the same volume for both the left and the right channels
            uint NewVolumeAllChannels = (((uint)NewVolume & 0x0000ffff) | ((uint)NewVolume << 16));
            // Set the volume
            waveOutSetVolume(IntPtr.Zero, NewVolumeAllChannels);
        }
    }

} 
 
         

  