﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZierbensTetris.Controller;
using ZierbensTetris.DataObj;
using ZierbensTetris.Model;

namespace ZierbensTetris.View
{
    public partial class GameViewer : Form
    {
        int gameState = 2;//0,开始，1，暂停，2，停止
        int gameMode = 0;//1 单人 2 双人 3 PVC
        int widthOfPiece = 28; 
        bool changedSet1 = false;
        bool changedSet2 = false;
        int maxScore = 0;
        int theStartVLevel = 0;
        int theStartHardLevel = 0;
        GameController controlOfGame; 

        #region 实现换分数委托部分

        private void changeDropMode(int index, bool dropDownMode)
        {
            Button tempB;
            if (index == 0) tempB = picDropDownMode;
            else tempB = picDropDownMode2; 
           
            if (!dropDownMode) tempB.ImageKey = "CommonDrop";
            else tempB.ImageKey = "SuperDrop";

            controlOfGame.SetDownToEndMode(index, dropDownMode);
        }
        private void changeScore(int index,int value)
        {
            if (index == 0)
            {
                labScore.Text = value.ToString();
                if (value > maxScore)
                {
                    maxScore = value;
                    labMaxScore.Text = maxScore.ToString();
                }
            }
            else
            {
                labScore2.Text = value.ToString();
                if (value > maxScore)
                {
                    maxScore = value;
                    labMaxScore.Text = maxScore.ToString();
                }
            }
        }
        private void changeLevel(int index, int value)
        {
            if(index == 0)labLevel.Text = value.ToString();
            else labLevel2.Text = value.ToString();
        }
        private void changeClearLines(int index, int value)
        {
            if (index == 0)
            {
                try
                {
                    labFight1.Text = controlOfGame.GetToActLineCount(0).ToString();
                }
                catch
                {
                    labFight1.Text = "0";
                }
                labClearLines.Text = value.ToString();
            }
            else
            {
                try
                {
                    labFight2.Text = controlOfGame.GetToActLineCount(1).ToString();
                }
                catch
                {
                    labFight2.Text = "0";
                }
                labClearLines2.Text = value.ToString();
            }
        }

        private void changeToActLines(int index, int value)
        {
            if (index == 0) labFight1.Text = value.ToString();
            else labFight2.Text = value.ToString();
        }

        #endregion

        private void getChangedSetMessage (int index)
        {
            if(index == 0)changedSet1 = true;
            else changedSet2 = true;
        }

        public GameViewer()
        {
            InitializeComponent();
            timer1.Start();
            controlOfGame = GameController.TheController; 
            controlOfGame.InitEnvironment( 21,10);
            theGamePanel1.Paint += new PaintEventHandler(theGamePanel1_Paint);
            theNextSets1.Paint += new PaintEventHandler(theNextSets1_Paint);
            controlOfGame.ChangeScore = new GameController.changeValue(changeScore);
            controlOfGame.ChangeLevel = new GameController.changeValue(changeLevel);
            controlOfGame.ChangeClearLines = new GameController.changeValue(changeClearLines);
            controlOfGame.TellChangeSet = new GameController.callOuter(getChangedSetMessage);
            controlOfGame.ChangeDropMode = new GameController.changeDropMode(changeDropMode);
            controlOfGame.ChangeToActLineCount = new GameController.changeValue(changeToActLines);   
            theGamePanel2.Paint += new PaintEventHandler(theGamePanel2_Paint);
            theNextSets2.Paint += new PaintEventHandler(theNextSets2_Paint);  
            tsStartV.Text = "起始速度 0";
            tsStartHardLevel.Text = "起始高度 0";
        }
        SetOfTetris lastShowNext1 = null;
        SetOfTetris lastShowNext2 = null;
        private void timer1_Tick(object sender, EventArgs e)
        {          
            if (gameState == 0)
            {   
                controlOfGame.PlayNextStep(); 
                 
                theGamePanel1.Refresh();
                SetOfTetris tempNextSet;
                tempNextSet = controlOfGame.GetTheNextSet(0);
                if (tempNextSet != null && !tempNextSet.Equals(lastShowNext1))
                {
                    lastShowNext1 = tempNextSet;
                    theNextSets1.Refresh();
                }

                if (gameMode != 1 )
                { 
                    theGamePanel2.Refresh();
                    tempNextSet = controlOfGame.GetTheNextSet(1);
                    if (tempNextSet != null && !tempNextSet.Equals(lastShowNext2))
                    {
                        lastShowNext2 = tempNextSet;
                        theNextSets2.Refresh();
                    }
                }              
            }
            else
            {
                //showStop() // showPause();
            }
        }
       
        /// <summary>
        /// 游戏开始
        /// </summary>
        /// <param name="mode">1，单人游戏 2，双人游戏 3，pk电脑</param>
        private void GameStart(int mode)
        {
            gameMode = mode; 
            labFight1.Text = "0";
            labFight2.Text = "0"; 
            changedSet1 = false;
            changedSet2 = false;
            int playerCount = 2;
            List<int> whoIsComputer = new List<int>();
            if (gameMode == 1) playerCount = 1;
            if (gameMode == 3)
            {
                whoIsComputer.Add(1);
            }
            if (gameMode == 4)
            {
                whoIsComputer.Add(0);
                whoIsComputer.Add(1);
            }
            controlOfGame.StartGame(playerCount,whoIsComputer,theStartVLevel, theStartHardLevel, 使用扩展方块ToolStripMenuItem.Checked);
            if (gameState == 2 || controlOfGame.SomeOneIsOver())
            {
                gameState = 0;
                //controlOfGame.SetPassThrowMode(0, 穿越模式ToolStripMenuItem.Checked);
                if (controlOfGame.GetPassThrowMode(0))
                    picPassThrowMode.ImageKey = "CanPassThrow";
                else
                    picPassThrowMode.ImageKey = "CannotPassThrow";
                if (!controlOfGame.GetDownToEndMode(0))
                    picDropDownMode.ImageKey = "CommonDrop";
                else
                    picDropDownMode.ImageKey = "SuperDrop";

                if (gameMode != 1)
                {
                    label11.Visible = false;
                    //controlOfGame.SetPassThrowMode(1, 穿越模式ToolStripMenuItem.Checked);
                    if (controlOfGame.GetPassThrowMode(1))
                        picPassThrowMode2.ImageKey = "CanPassThrow";
                    else
                        picPassThrowMode2.ImageKey = "CannotPassThrow";
                    if (!controlOfGame.GetDownToEndMode(1))
                        picDropDownMode2.ImageKey = "CommonDrop";
                    else
                        picDropDownMode2.ImageKey = "SuperDrop";
                }
            }
        }

        #region 重画的区域 
       
        void theNextSets1_Paint(object sender, PaintEventArgs e)
        {
            if (lastShowNext1 == null) return;

            SolidBrush theBruksh = new SolidBrush(lastShowNext1.DefaultColor);
            for (int i = 0; i < lastShowNext1.PositionList.Count; i++)
            {
                XYPair thePosition = lastShowNext1.PositionList[i];
                e.Graphics.DrawRectangle(new Pen(Color.Black), new Rectangle(widthOfPiece * thePosition.X  + 2, widthOfPiece * thePosition.Y  + 2, widthOfPiece - 2, widthOfPiece - 2));
                e.Graphics.FillRectangle(theBruksh, new Rectangle(widthOfPiece * thePosition.X +3 , widthOfPiece * thePosition.Y +3, widthOfPiece - 3, widthOfPiece - 3));
                e.Graphics.DrawRectangle(new Pen(Color.White), new Rectangle(widthOfPiece * thePosition.X + 5, widthOfPiece * thePosition.Y + 5, widthOfPiece - 8, widthOfPiece - 8));
                e.Graphics.FillRectangle(new SolidBrush(Color.White), new Rectangle(widthOfPiece * thePosition.X + 8, widthOfPiece * thePosition.Y + 8, 3, 5));
            }
        }
      
        void theNextSets2_Paint(object sender, PaintEventArgs e)
        {
            if (lastShowNext2 == null) return;

            SolidBrush theBruksh = new SolidBrush(lastShowNext2.DefaultColor);
            for (int i = 0; i < lastShowNext2.PositionList.Count; i++)
            {
                XYPair thePosition = lastShowNext2.PositionList[i];
                e.Graphics.DrawRectangle(new Pen(Color.Black), new Rectangle(widthOfPiece * thePosition.X + 2, widthOfPiece * thePosition.Y + 2, widthOfPiece - 2, widthOfPiece - 2));
                e.Graphics.FillRectangle(theBruksh, new Rectangle(widthOfPiece * thePosition.X +3 , widthOfPiece * thePosition.Y +3 , widthOfPiece - 3, widthOfPiece - 3));
                e.Graphics.DrawRectangle(new Pen(Color.White), new Rectangle(widthOfPiece * thePosition.X + 5, widthOfPiece * thePosition.Y + 5, widthOfPiece - 8, widthOfPiece - 8));
                e.Graphics.FillRectangle(new SolidBrush(Color.White), new Rectangle(widthOfPiece * thePosition.X + 8, widthOfPiece * thePosition.Y + 8, 3, 5));
            }
        }
        void theGamePanel1_Paint(object sender, PaintEventArgs e)
        {
            paintGamePanel(0,theGamePanel1, e.Graphics);            
        }
        void theGamePanel2_Paint(object sender, PaintEventArgs e)
        {
            paintGamePanel(1,theGamePanel2, e.Graphics);       
        }

        private void paintGamePanel(int index,PictureBox thePanel,Graphics theG)
        {
            SolidBrush theTrans = new SolidBrush(Color.FromArgb(50, 205, 208, 200));
            if (controlOfGame.PlayerCount < index + 1)
            {
                theG.FillRectangle(theTrans, 0, 0, thePanel.Width, thePanel.Height);
                return;
            } 
           
            theG.FillRectangle(theTrans, 0, 0, thePanel.Width, thePanel.Height);

            SetOfTetris toDraw = controlOfGame.GetTheMovingSet(index);

            #region 画静止的块
            Pen drawPen = new Pen(Color.DarkSalmon);
            Pen drawPenIn = new Pen(Color.WhiteSmoke);
            SolidBrush theBruksh;
            SolidBrush theBrukshOfLight = new SolidBrush(Color.White);
            for (int i = 0; i < controlOfGame.ColumnsCount; i++)
            {
                for (int r = 0; r < controlOfGame.RowsCount; r++)
                {
                    theBruksh = new SolidBrush(controlOfGame.GetTheModel(index).AllPiece[i, r].TheColor);

                    switch  (controlOfGame.GetTheModel(index).AllPiece[i, r].State )
                    {
                        case -1:
                            //drawPenIn.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                            theG.DrawRectangle(drawPenIn, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r - 1, widthOfPiece - 2, widthOfPiece - 2));
                            continue;
                        case 4:
                            theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r + 14, widthOfPiece - 2, 2));
                            continue;
                        case 3:
                            theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r + 10, widthOfPiece - 2, 10));
                            continue; 
                        case 2:
                            theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r + 5, widthOfPiece - 2, 20));
                            continue; 
                        case 1:
                            theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r - 1, widthOfPiece - 2, 28));
                            continue; 
                    }
                    theG.DrawRectangle(drawPen, new Rectangle(widthOfPiece * i + 1, widthOfPiece * r - 1, widthOfPiece - 2, widthOfPiece - 2));
                    theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * i+2 , widthOfPiece * r , widthOfPiece - 3, widthOfPiece - 3));

                    theG.DrawRectangle(drawPenIn, new Rectangle(widthOfPiece * i  + 4, widthOfPiece * r  + 2, widthOfPiece - 8, widthOfPiece - 8));
                    theG.FillRectangle(theBrukshOfLight, new Rectangle(widthOfPiece * i  +7 , widthOfPiece * r  +5, 3, 5)); 
                }
            }
            #endregion

            #region  画移动的块
            drawPen.Color = Color.WhiteSmoke;
            if (toDraw == null) return;
            drawPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            theBruksh = new SolidBrush(toDraw.DefaultColor);
            for (int i = 0; i < toDraw.PositionList.Count; i++)
            {
                XYPair thePosition = toDraw.PositionList[i].Add(controlOfGame.GetTheModel(index).TheMovingSetPosition);
                theG.DrawRectangle(drawPen, new Rectangle(widthOfPiece * thePosition.X + 1, widthOfPiece * thePosition.Y - 1, widthOfPiece - 2, widthOfPiece - 2));
                theG.FillRectangle(theBruksh, new Rectangle(widthOfPiece * thePosition.X + 2, widthOfPiece * thePosition.Y, widthOfPiece - 3, widthOfPiece - 3));
                theG.DrawRectangle(drawPenIn,new Rectangle(widthOfPiece * thePosition.X  + 4, widthOfPiece * thePosition.Y  + 2, widthOfPiece - 8, widthOfPiece - 8));
                theG.FillRectangle(theBrukshOfLight, new Rectangle(widthOfPiece * thePosition.X  + 7, widthOfPiece * thePosition.Y  + 5, 3, 5));
            }
            #endregion
        }
     
        //private void drawingAPiece(Graphics g, int x, int y, PieceOfPad thePiece)
        //{
        //    //在这里实现绘图，如果是用贴图方式，则对应thePiece的不同状态，对应不同的图形，
        //    //如果是普通的画方框方式，则在这里画方框
        //    int beginX, beginY;
        //}
        #endregion


        #region 按钮响应的部分
        private void actor(bool theFirstPlayer)
        {
            if (gameMode != 1)
            {
                if (theFirstPlayer)
                {
                    if (controlOfGame.GetTheModel (0).ToActLineCount <= 0 || controlOfGame.SomeOneIsOver()) return;
                    controlOfGame.Fight(0, 1);              
                }
                else
                {
                    if (controlOfGame.GetTheModel(1).ToActLineCount <= 0 || controlOfGame.SomeOneIsOver()) return;
                    controlOfGame.Fight(1,0);
                }
            }
        } 

        private void playChange(bool theFirstPlayer)
        {
            if (theFirstPlayer) controlOfGame.Turn(0);
            else controlOfGame.Turn(1);
        }
        private void moveLeft(bool theFirstPlayer)
        {
            if (theFirstPlayer) controlOfGame.MoveLeft(0);
            else controlOfGame.MoveLeft(1);
        }
        private void moveRight(bool theFirstPlayer)
        {
            if (theFirstPlayer) controlOfGame.MoveRight(0);
            else controlOfGame.MoveRight(1);
        }
        private void fasterDrop(bool theFirstPlayer)
        {
            if (theFirstPlayer)
            {
                if(!changedSet1)
                controlOfGame.FasterDrop(0);
            }
            else
            {
                if(!changedSet2)
                controlOfGame.FasterDrop(1);
            }
        }
        private void pauseGame()
        {
            if (gameState != 2) gameState = 1 - gameState;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            playChange(true);
        }


        private void btnLeftCircle_Click(object sender, EventArgs e)
        {
            try
            {
                controlOfGame.GetTheModel(0).Hourwise = !controlOfGame.GetTheModel(0).Hourwise;
                if (controlOfGame.GetTheModel(0).Hourwise)
                    btnPlay1Dirctor.ImageKey = "HourWise";
                else
                    btnPlay1Dirctor.ImageKey = "InvertHour";
            }
            catch{}
        }

        private void btnRightCircle_Click(object sender, EventArgs e)
        {
            try
            {
                controlOfGame.GetTheModel(1).Hourwise = !controlOfGame.GetTheModel(1).Hourwise;
            if (controlOfGame.GetTheModel(1).Hourwise)
                btnPlay2Dirctor.ImageKey = "HourWise";
            else
                btnPlay2Dirctor.ImageKey = "InvertHour";
            }
            catch{}
        }


        private void btnLeftMove_Click(object sender, EventArgs e)
        {
            moveLeft(true);
        }

        private void btnQuickDown_Click(object sender, EventArgs e)
        {
            fasterDrop(true);
        }

        private void btnRightMove_Click(object sender, EventArgs e)
        {
            moveRight(true);
        }

        private void errDing()
        {
            //可以在这加入声音!!!!!
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            pauseGame();
        }

     

        /// <summary>
        /// 屏蔽原来的方向键切换tab的问题 
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessDialogKey(Keys keyCode)
        {
            if (keyCode == Keys.P) pauseGame();
            else if (keyCode == Keys.F1) help();
            else if (keyCode == Keys.F2) GameStart(1);
            else if (keyCode == Keys.F3) GameStart(2);
            else if (keyCode == Keys.F7) GameStart(3);
            else if (keyCode == Keys.F8) GameStart(4);
            else if (gameState == 0)
            {
                switch (keyCode)
                {
                    case Keys.W:
                        playChange(true); break;
                    case Keys.Up:
                        playChange(gameMode != 2); break;
                    case Keys.A:
                        moveLeft(true); break;
                    case Keys.Left:
                        moveLeft(gameMode != 2); break;
                    case Keys.D:
                        moveRight(true); break;
                    case Keys.Right:
                        moveRight(gameMode != 2); break;
                    case Keys.S:
                        fasterDrop(true); break;
                    case Keys.Down:
                        fasterDrop(gameMode != 2); break;
                    case Keys.E:
                        actor(true); break;
                    case Keys.Delete:
                        actor(gameMode != 2); break;
                    case Keys.Q:
                        changeDropMode(0, picDropDownMode.ImageKey == "CommonDrop"); break;
                    case Keys.Home:
                        if (gameMode != 2) changeDropMode(0, picDropDownMode.ImageKey == "CommonDrop");
                        else changeDropMode(1, picDropDownMode2.ImageKey == "CommonDrop");
                        break;
                }
            }
            return true;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 穿越模式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (gameState != 2)
            {
                MessageBox.Show("为了不降低游戏的公平性,不允许在游戏过程中切换这种扩展模式");
                return;
            }
            穿越模式ToolStripMenuItem.Checked = !穿越模式ToolStripMenuItem.Checked;
            controlOfGame.SetPassThrowMode(0,穿越模式ToolStripMenuItem.Checked);
            if (controlOfGame.GetPassThrowMode(0))
                picPassThrowMode.ImageKey = "CanPassThrow";
            else
                picPassThrowMode.ImageKey = "CannotPassThrow";
        }
       
        private void 单人游戏F2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(1);
        }
        private void help()
        {
            FrmHelp f = new FrmHelp();
            f.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            help();
        }

        private void 音效ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            音效ToolStripMenuItem.Checked = !音效ToolStripMenuItem.Checked;           
        }

        private void tsStartV_SelectedIndexChanged(object sender, EventArgs e)
        {
             if (gameState != 2)
            {
                MessageBox.Show("为了不降低游戏的公平性,不允许在游戏过程中切换这种扩展模式");
               
                return;
            }
            if (!string.IsNullOrEmpty(tsStartV.Text) && tsStartV.Text.Length > 0)
            {
                theStartVLevel = int.Parse(tsStartV.Text.Substring(tsStartV.Text.Length - 1));                
            }
        }
      
        private void picDropDownMode_Click(object sender, EventArgs e)
        {
            changeDropMode(0, picDropDownMode.ImageKey == "CommonDrop");          
        }
        private void fightwithcomputer_Click(object sender, EventArgs e)
        {
            GameStart(3);
        }

        private void 双人对战ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(2);
        }
        private void picDropDownMode2_Click(object sender, EventArgs e)
        {
            changeDropMode(1, picDropDownMode2.ImageKey == "CommonDrop");
        }

        private void tsStartHardLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (gameState != 2)
            {
                MessageBox.Show("为了不降低游戏的公平性,不允许在游戏过程中切换这种扩展模式");
                return;
            }
            if (!string.IsNullOrEmpty(tsStartHardLevel.Text) && tsStartHardLevel.Text.Length > 0)
            {
                theStartHardLevel = int.Parse(tsStartHardLevel.Text.Substring(tsStartHardLevel.Text.Length - 2));
            }

        }
        #endregion

        private void 暂停游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pauseGame();
        }

        private void 终止对战ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gameState = 2;
            controlOfGame.GetTheModel(0).GameOver= true;
            controlOfGame.GetTheModel(1).GameOver = true;
        }

        private void GameViewer_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)//
                if (gameMode == 2)
                    changedSet2 = false;
                else
                    changedSet1 = false;
            else if(e.KeyCode == Keys.S)
                changedSet1 = false;
        }

        private void 电脑互相PKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(4);
            controlOfGame.GetTheModel(0).AILevel = 3;
            controlOfGame.GetTheModel(1).AILevel = 3;
        }

        private void 稍微难一点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(3);
            controlOfGame.GetTheModel(0).AILevel = 3;
            controlOfGame.GetTheModel(1).AILevel = 3;
            
        }

        private void 稍微容易一点的ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(3);
            controlOfGame.GetTheModel(0).AILevel = 2;
            controlOfGame.GetTheModel(1).AILevel = 2;
            
        }

        private void 小饼子ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameStart(3);
            controlOfGame.GetTheModel(0).AILevel = 1;
            controlOfGame.GetTheModel(1).AILevel = 1; 
        }

        private void 使用扩展方块ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            使用扩展方块ToolStripMenuItem.Checked = !使用扩展方块ToolStripMenuItem.Checked;
        }
         
        private void GameViewer_Load(object sender, EventArgs e)
        {
            this.Text += "["+System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()+"]";
            tsmV1_Click(null, null); 
        }
        private void makeOtherNotCheck()
        {
            tsmV0.Checked = false;
            tsmV1.Checked = false;
            tsmV2.Checked = false;
            tsmV3.Checked = false;
            tsmV4.Checked = false;
            tsmV5.Checked = false;
            tsmV6.Checked = false;
            tsmV7.Checked = false;
            tsmV8.Checked = false;
            tsmV9.Checked = false;
            tsmV10.Checked = false; 
        }
        private void tsmV0_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV0.Checked = true;
            GameControllerOfSound.SetVolume(0);
        }

        private void tsmV1_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV1.Checked = true;
            GameControllerOfSound.SetVolume(1);
        }

        private void tsmV2_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV2.Checked = true;
            GameControllerOfSound.SetVolume(2);
        }

        private void tsmV3_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV3.Checked = true;
            GameControllerOfSound.SetVolume(3);
        }

        private void tsmV4_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV4.Checked = true;
            GameControllerOfSound.SetVolume(4);
        }

        private void tsmV5_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV5.Checked = true;
            GameControllerOfSound.SetVolume(5);
        }

        private void tsmV6_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV6.Checked = true;
            GameControllerOfSound.SetVolume(6);
        }

        private void tsmV7_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV7.Checked = true;
            GameControllerOfSound.SetVolume(7);
        }

        private void tsmV8_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV8.Checked = true;
            GameControllerOfSound.SetVolume(8);
        }

        private void tsmV9_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV9.Checked = true;
            GameControllerOfSound.SetVolume(9);
        }

        private void tsmV10_Click(object sender, EventArgs e)
        {
            makeOtherNotCheck();
            tsmV10.Checked = true;
            GameControllerOfSound.SetVolume(10);
        }
         
    }
}