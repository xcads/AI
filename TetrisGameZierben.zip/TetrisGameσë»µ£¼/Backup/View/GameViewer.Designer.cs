﻿namespace ZierbensTetris.View
{
    partial class GameViewer
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameViewer));
            this.theGamePanel1 = new System.Windows.Forms.PictureBox();
            this.theNextSets1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnPause = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labLevel = new System.Windows.Forms.Label();
            this.labScore = new System.Windows.Forms.Label();
            this.labMaxScore = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.theNextSets2 = new System.Windows.Forms.PictureBox();
            this.theGamePanel2 = new System.Windows.Forms.PictureBox();
            this.labScore2 = new System.Windows.Forms.Label();
            this.labLevel2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.暂停游戏ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.终止对战ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.单人游戏F2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fightWithComputer = new System.Windows.Forms.ToolStripMenuItem();
            this.稍微难一点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.稍微容易一点的ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.小饼子ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.双人对战ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.使用扩展方块ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.穿越模式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsStartV = new System.Windows.Forms.ToolStripComboBox();
            this.tsStartHardLevel = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.练习01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.练习02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.闯关01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.闯关02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton4 = new System.Windows.Forms.ToolStripDropDownButton();
            this.背景音乐ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.音效ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV0 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV5 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV6 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV7 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV8 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV9 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmV10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.图片设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.电脑互相PKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.label14 = new System.Windows.Forms.Label();
            this.labClearLines = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labClearLines2 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.picPassThrowMode = new System.Windows.Forms.Button();
            this.picDropDownMode = new System.Windows.Forms.Button();
            this.picDropDownMode2 = new System.Windows.Forms.Button();
            this.picPassThrowMode2 = new System.Windows.Forms.Button();
            this.btnPlay1Dirctor = new System.Windows.Forms.Button();
            this.btnPlay2Dirctor = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labFight1 = new System.Windows.Forms.Label();
            this.labFight2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.theGamePanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.theNextSets1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.theNextSets2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.theGamePanel2)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // theGamePanel1
            // 
            this.theGamePanel1.BackColor = System.Drawing.Color.Honeydew;
            this.theGamePanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theGamePanel1.Location = new System.Drawing.Point(12, 51);
            this.theGamePanel1.Name = "theGamePanel1";
            this.theGamePanel1.Size = new System.Drawing.Size(284, 593);
            this.theGamePanel1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.theGamePanel1.TabIndex = 0;
            this.theGamePanel1.TabStop = false;
            // 
            // theNextSets1
            // 
            this.theNextSets1.BackColor = System.Drawing.Color.Cornsilk;
            this.theNextSets1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theNextSets1.Location = new System.Drawing.Point(317, 84);
            this.theNextSets1.Name = "theNextSets1";
            this.theNextSets1.Size = new System.Drawing.Size(125, 125);
            this.theNextSets1.TabIndex = 1;
            this.theNextSets1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 60;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(432, 297);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(71, 39);
            this.btnPause.TabIndex = 0;
            this.btnPause.TabStop = false;
            this.btnPause.Text = "PAUSE(P)";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(333, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "得分";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(332, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "速度";
            // 
            // labLevel
            // 
            this.labLevel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labLevel.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labLevel.Location = new System.Drawing.Point(368, 235);
            this.labLevel.Name = "labLevel";
            this.labLevel.Size = new System.Drawing.Size(71, 22);
            this.labLevel.TabIndex = 6;
            this.labLevel.Text = "0";
            this.labLevel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labScore
            // 
            this.labScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labScore.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labScore.Location = new System.Drawing.Point(368, 212);
            this.labScore.Name = "labScore";
            this.labScore.Size = new System.Drawing.Size(71, 22);
            this.labScore.TabIndex = 7;
            this.labScore.Text = "0";
            this.labScore.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labMaxScore
            // 
            this.labMaxScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labMaxScore.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labMaxScore.Location = new System.Drawing.Point(406, 51);
            this.labMaxScore.Name = "labMaxScore";
            this.labMaxScore.Size = new System.Drawing.Size(133, 30);
            this.labMaxScore.TabIndex = 9;
            this.labMaxScore.Text = "0";
            this.labMaxScore.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(317, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "HIGHEST SCORE";
            // 
            // theNextSets2
            // 
            this.theNextSets2.BackColor = System.Drawing.Color.Cornsilk;
            this.theNextSets2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theNextSets2.Location = new System.Drawing.Point(495, 84);
            this.theNextSets2.Name = "theNextSets2";
            this.theNextSets2.Size = new System.Drawing.Size(125, 125);
            this.theNextSets2.TabIndex = 19;
            this.theNextSets2.TabStop = false;
            // 
            // theGamePanel2
            // 
            this.theGamePanel2.BackColor = System.Drawing.Color.Honeydew;
            this.theGamePanel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.theGamePanel2.Location = new System.Drawing.Point(653, 51);
            this.theGamePanel2.Name = "theGamePanel2";
            this.theGamePanel2.Size = new System.Drawing.Size(284, 593);
            this.theGamePanel2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.theGamePanel2.TabIndex = 13;
            this.theGamePanel2.TabStop = false;
            // 
            // labScore2
            // 
            this.labScore2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labScore2.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labScore2.Location = new System.Drawing.Point(540, 212);
            this.labScore2.Name = "labScore2";
            this.labScore2.Size = new System.Drawing.Size(71, 22);
            this.labScore2.TabIndex = 33;
            this.labScore2.Text = "0";
            this.labScore2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labLevel2
            // 
            this.labLevel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labLevel2.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labLevel2.Location = new System.Drawing.Point(540, 235);
            this.labLevel2.Name = "labLevel2";
            this.labLevel2.Size = new System.Drawing.Size(71, 22);
            this.labLevel2.TabIndex = 32;
            this.labLevel2.Text = "0";
            this.labLevel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(504, 240);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 31;
            this.label12.Text = "速度";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(505, 218);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 30;
            this.label13.Text = "得分";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton3,
            this.toolStripDropDownButton2,
            this.toolStripDropDownButton4,
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(946, 41);
            this.toolStrip1.TabIndex = 37;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.暂停游戏ToolStripMenuItem,
            this.终止对战ToolStripMenuItem,
            this.toolStripMenuItem8,
            this.单人游戏F2ToolStripMenuItem,
            this.fightWithComputer,
            this.双人对战ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.使用扩展方块ToolStripMenuItem,
            this.穿越模式ToolStripMenuItem,
            this.toolStripMenuItem7,
            this.tsStartV,
            this.tsStartHardLevel});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(174, 38);
            this.toolStripDropDownButton1.Text = "传统俄罗斯方块";
            // 
            // 暂停游戏ToolStripMenuItem
            // 
            this.暂停游戏ToolStripMenuItem.Name = "暂停游戏ToolStripMenuItem";
            this.暂停游戏ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.暂停游戏ToolStripMenuItem.Text = "暂停游戏         [P]";
            this.暂停游戏ToolStripMenuItem.Click += new System.EventHandler(this.暂停游戏ToolStripMenuItem_Click);
            // 
            // 终止对战ToolStripMenuItem
            // 
            this.终止对战ToolStripMenuItem.Name = "终止对战ToolStripMenuItem";
            this.终止对战ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.终止对战ToolStripMenuItem.Text = "终止对战";
            this.终止对战ToolStripMenuItem.Click += new System.EventHandler(this.终止对战ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(245, 6);
            // 
            // 单人游戏F2ToolStripMenuItem
            // 
            this.单人游戏F2ToolStripMenuItem.Name = "单人游戏F2ToolStripMenuItem";
            this.单人游戏F2ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.单人游戏F2ToolStripMenuItem.Text = "单人游戏         [F2]";
            this.单人游戏F2ToolStripMenuItem.Click += new System.EventHandler(this.单人游戏F2ToolStripMenuItem_Click);
            // 
            // fightWithComputer
            // 
            this.fightWithComputer.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.稍微难一点ToolStripMenuItem,
            this.稍微容易一点的ToolStripMenuItem,
            this.小饼子ToolStripMenuItem});
            this.fightWithComputer.Name = "fightWithComputer";
            this.fightWithComputer.Size = new System.Drawing.Size(248, 30);
            this.fightWithComputer.Text = "与电脑对战      [F7]";
            this.fightWithComputer.Click += new System.EventHandler(this.fightwithcomputer_Click);
            // 
            // 稍微难一点ToolStripMenuItem
            // 
            this.稍微难一点ToolStripMenuItem.Name = "稍微难一点ToolStripMenuItem";
            this.稍微难一点ToolStripMenuItem.Size = new System.Drawing.Size(223, 30);
            this.稍微难一点ToolStripMenuItem.Text = "难 电脑要求略高";
            this.稍微难一点ToolStripMenuItem.Click += new System.EventHandler(this.稍微难一点ToolStripMenuItem_Click);
            // 
            // 稍微容易一点的ToolStripMenuItem
            // 
            this.稍微容易一点的ToolStripMenuItem.Name = "稍微容易一点的ToolStripMenuItem";
            this.稍微容易一点的ToolStripMenuItem.Size = new System.Drawing.Size(223, 30);
            this.稍微容易一点的ToolStripMenuItem.Text = "中 电脑要求一般";
            this.稍微容易一点的ToolStripMenuItem.Click += new System.EventHandler(this.稍微容易一点的ToolStripMenuItem_Click);
            // 
            // 小饼子ToolStripMenuItem
            // 
            this.小饼子ToolStripMenuItem.Name = "小饼子ToolStripMenuItem";
            this.小饼子ToolStripMenuItem.Size = new System.Drawing.Size(223, 30);
            this.小饼子ToolStripMenuItem.Text = "极易 无要求";
            this.小饼子ToolStripMenuItem.Click += new System.EventHandler(this.小饼子ToolStripMenuItem_Click);
            // 
            // 双人对战ToolStripMenuItem
            // 
            this.双人对战ToolStripMenuItem.Name = "双人对战ToolStripMenuItem";
            this.双人对战ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.双人对战ToolStripMenuItem.Text = "双人对战         [F3]";
            this.双人对战ToolStripMenuItem.Click += new System.EventHandler(this.双人对战ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(245, 6);
            // 
            // 使用扩展方块ToolStripMenuItem
            // 
            this.使用扩展方块ToolStripMenuItem.Name = "使用扩展方块ToolStripMenuItem";
            this.使用扩展方块ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.使用扩展方块ToolStripMenuItem.Text = "使用扩展方块";
            this.使用扩展方块ToolStripMenuItem.Click += new System.EventHandler(this.使用扩展方块ToolStripMenuItem_Click);
            // 
            // 穿越模式ToolStripMenuItem
            // 
            this.穿越模式ToolStripMenuItem.Name = "穿越模式ToolStripMenuItem";
            this.穿越模式ToolStripMenuItem.ShowShortcutKeys = false;
            this.穿越模式ToolStripMenuItem.Size = new System.Drawing.Size(248, 30);
            this.穿越模式ToolStripMenuItem.Text = "穿越模式";
            this.穿越模式ToolStripMenuItem.Click += new System.EventHandler(this.穿越模式ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(245, 6);
            // 
            // tsStartV
            // 
            this.tsStartV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tsStartV.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tsStartV.Items.AddRange(new object[] {
            "起始速度 0",
            "起始速度 1",
            "起始速度 2",
            "起始速度 3",
            "起始速度 4",
            "起始速度 5",
            "起始速度 6",
            "起始速度 7",
            "起始速度 8",
            "起始速度 9"});
            this.tsStartV.Name = "tsStartV";
            this.tsStartV.Size = new System.Drawing.Size(131, 33);
            this.tsStartV.SelectedIndexChanged += new System.EventHandler(this.tsStartV_SelectedIndexChanged);
            // 
            // tsStartHardLevel
            // 
            this.tsStartHardLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tsStartHardLevel.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tsStartHardLevel.Items.AddRange(new object[] {
            "起始高度 0",
            "起始高度 1",
            "起始高度 2",
            "起始高度 3",
            "起始高度 4",
            "起始高度 5",
            "起始高度 6",
            "起始高度 7",
            "起始高度 8",
            "起始高度 9",
            "起始高度 10",
            "起始高度 11",
            "起始高度 12",
            "起始高度 13"});
            this.tsStartHardLevel.Name = "tsStartHardLevel";
            this.tsStartHardLevel.Size = new System.Drawing.Size(131, 33);
            this.tsStartHardLevel.SelectedIndexChanged += new System.EventHandler(this.tsStartHardLevel_SelectedIndexChanged);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.Enabled = false;
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(117, 38);
            this.toolStripDropDownButton3.Text = "剧情模式";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.练习01ToolStripMenuItem,
            this.练习02ToolStripMenuItem,
            this.toolStripMenuItem3,
            this.闯关01ToolStripMenuItem,
            this.闯关02ToolStripMenuItem,
            this.toolStripMenuItem5});
            this.toolStripDropDownButton2.Enabled = false;
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(155, 38);
            this.toolStripDropDownButton2.Text = "挑战闯关模式";
            // 
            // 练习01ToolStripMenuItem
            // 
            this.练习01ToolStripMenuItem.Enabled = false;
            this.练习01ToolStripMenuItem.Name = "练习01ToolStripMenuItem";
            this.练习01ToolStripMenuItem.Size = new System.Drawing.Size(144, 30);
            this.练习01ToolStripMenuItem.Text = "练习01";
            // 
            // 练习02ToolStripMenuItem
            // 
            this.练习02ToolStripMenuItem.Enabled = false;
            this.练习02ToolStripMenuItem.Name = "练习02ToolStripMenuItem";
            this.练习02ToolStripMenuItem.Size = new System.Drawing.Size(144, 30);
            this.练习02ToolStripMenuItem.Text = "练习02";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(141, 6);
            // 
            // 闯关01ToolStripMenuItem
            // 
            this.闯关01ToolStripMenuItem.Enabled = false;
            this.闯关01ToolStripMenuItem.Name = "闯关01ToolStripMenuItem";
            this.闯关01ToolStripMenuItem.Size = new System.Drawing.Size(144, 30);
            this.闯关01ToolStripMenuItem.Text = "闯关01";
            // 
            // 闯关02ToolStripMenuItem
            // 
            this.闯关02ToolStripMenuItem.Enabled = false;
            this.闯关02ToolStripMenuItem.Name = "闯关02ToolStripMenuItem";
            this.闯关02ToolStripMenuItem.Size = new System.Drawing.Size(144, 30);
            this.闯关02ToolStripMenuItem.Text = "闯关02";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Enabled = false;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(144, 30);
            this.toolStripMenuItem5.Text = "...";
            // 
            // toolStripDropDownButton4
            // 
            this.toolStripDropDownButton4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.背景音乐ToolStripMenuItem,
            this.音效ToolStripMenuItem,
            this.toolStripMenuItem4,
            this.图片设置ToolStripMenuItem,
            this.toolStripMenuItem6,
            this.电脑互相PKToolStripMenuItem});
            this.toolStripDropDownButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton4.Image")));
            this.toolStripDropDownButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton4.Name = "toolStripDropDownButton4";
            this.toolStripDropDownButton4.Size = new System.Drawing.Size(117, 38);
            this.toolStripDropDownButton4.Text = "其他设置";
            // 
            // 背景音乐ToolStripMenuItem
            // 
            this.背景音乐ToolStripMenuItem.CheckOnClick = true;
            this.背景音乐ToolStripMenuItem.Enabled = false;
            this.背景音乐ToolStripMenuItem.Name = "背景音乐ToolStripMenuItem";
            this.背景音乐ToolStripMenuItem.Size = new System.Drawing.Size(241, 30);
            this.背景音乐ToolStripMenuItem.Text = "背景音乐";
            // 
            // 音效ToolStripMenuItem
            // 
            this.音效ToolStripMenuItem.CheckOnClick = true;
            this.音效ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmV0,
            this.tsmV1,
            this.tsmV2,
            this.tsmV3,
            this.tsmV4,
            this.tsmV5,
            this.tsmV6,
            this.tsmV7,
            this.tsmV8,
            this.tsmV9,
            this.tsmV10});
            this.音效ToolStripMenuItem.Name = "音效ToolStripMenuItem";
            this.音效ToolStripMenuItem.Size = new System.Drawing.Size(241, 30);
            this.音效ToolStripMenuItem.Text = "音效";
            this.音效ToolStripMenuItem.Click += new System.EventHandler(this.音效ToolStripMenuItem_Click);
            // 
            // tsmV0
            // 
            this.tsmV0.Name = "tsmV0";
            this.tsmV0.Size = new System.Drawing.Size(117, 30);
            this.tsmV0.Text = "0";
            this.tsmV0.Click += new System.EventHandler(this.tsmV0_Click);
            // 
            // tsmV1
            // 
            this.tsmV1.Name = "tsmV1";
            this.tsmV1.Size = new System.Drawing.Size(117, 30);
            this.tsmV1.Text = "10";
            this.tsmV1.Click += new System.EventHandler(this.tsmV1_Click);
            // 
            // tsmV2
            // 
            this.tsmV2.Name = "tsmV2";
            this.tsmV2.Size = new System.Drawing.Size(117, 30);
            this.tsmV2.Text = "20";
            this.tsmV2.Click += new System.EventHandler(this.tsmV2_Click);
            // 
            // tsmV3
            // 
            this.tsmV3.Name = "tsmV3";
            this.tsmV3.Size = new System.Drawing.Size(117, 30);
            this.tsmV3.Text = "30";
            this.tsmV3.Click += new System.EventHandler(this.tsmV3_Click);
            // 
            // tsmV4
            // 
            this.tsmV4.Name = "tsmV4";
            this.tsmV4.Size = new System.Drawing.Size(117, 30);
            this.tsmV4.Text = "40";
            this.tsmV4.Click += new System.EventHandler(this.tsmV4_Click);
            // 
            // tsmV5
            // 
            this.tsmV5.Name = "tsmV5";
            this.tsmV5.Size = new System.Drawing.Size(117, 30);
            this.tsmV5.Text = "50";
            this.tsmV5.Click += new System.EventHandler(this.tsmV5_Click);
            // 
            // tsmV6
            // 
            this.tsmV6.Name = "tsmV6";
            this.tsmV6.Size = new System.Drawing.Size(117, 30);
            this.tsmV6.Text = "60";
            this.tsmV6.Click += new System.EventHandler(this.tsmV6_Click);
            // 
            // tsmV7
            // 
            this.tsmV7.Name = "tsmV7";
            this.tsmV7.Size = new System.Drawing.Size(117, 30);
            this.tsmV7.Text = "70";
            this.tsmV7.Click += new System.EventHandler(this.tsmV7_Click);
            // 
            // tsmV8
            // 
            this.tsmV8.Name = "tsmV8";
            this.tsmV8.Size = new System.Drawing.Size(117, 30);
            this.tsmV8.Text = "80";
            this.tsmV8.Click += new System.EventHandler(this.tsmV8_Click);
            // 
            // tsmV9
            // 
            this.tsmV9.Name = "tsmV9";
            this.tsmV9.Size = new System.Drawing.Size(117, 30);
            this.tsmV9.Text = "90";
            this.tsmV9.Click += new System.EventHandler(this.tsmV9_Click);
            // 
            // tsmV10
            // 
            this.tsmV10.Name = "tsmV10";
            this.tsmV10.Size = new System.Drawing.Size(117, 30);
            this.tsmV10.Text = "100";
            this.tsmV10.Click += new System.EventHandler(this.tsmV10_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(238, 6);
            // 
            // 图片设置ToolStripMenuItem
            // 
            this.图片设置ToolStripMenuItem.Enabled = false;
            this.图片设置ToolStripMenuItem.Name = "图片设置ToolStripMenuItem";
            this.图片设置ToolStripMenuItem.Size = new System.Drawing.Size(241, 30);
            this.图片设置ToolStripMenuItem.Text = "图片设置";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(238, 6);
            // 
            // 电脑互相PKToolStripMenuItem
            // 
            this.电脑互相PKToolStripMenuItem.Name = "电脑互相PKToolStripMenuItem";
            this.电脑互相PKToolStripMenuItem.Size = new System.Drawing.Size(241, 30);
            this.电脑互相PKToolStripMenuItem.Text = "电脑互相PK    [F8]";
            this.电脑互相PKToolStripMenuItem.Click += new System.EventHandler(this.电脑互相PKToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(103, 38);
            this.toolStripButton1.Text = "说明[F1]";
            this.toolStripButton1.ToolTipText = "说明 F1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(142, 38);
            this.toolStripButton2.Text = "退出[Alt+F4]";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(332, 263);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 3;
            this.label14.Text = "行数";
            // 
            // labClearLines
            // 
            this.labClearLines.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labClearLines.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labClearLines.Location = new System.Drawing.Point(368, 258);
            this.labClearLines.Name = "labClearLines";
            this.labClearLines.Size = new System.Drawing.Size(71, 22);
            this.labClearLines.TabIndex = 6;
            this.labClearLines.Text = "0";
            this.labClearLines.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(504, 263);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 3;
            this.label16.Text = "行数";
            // 
            // labClearLines2
            // 
            this.labClearLines2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labClearLines2.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labClearLines2.Location = new System.Drawing.Point(540, 258);
            this.labClearLines2.Name = "labClearLines2";
            this.labClearLines2.Size = new System.Drawing.Size(71, 22);
            this.labClearLines2.TabIndex = 6;
            this.labClearLines2.Text = "0";
            this.labClearLines2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "CanPassThrow");
            this.imageList1.Images.SetKeyName(1, "CannotPassThrow");
            this.imageList1.Images.SetKeyName(2, "SuperDrop");
            this.imageList1.Images.SetKeyName(3, "CommonDrop");
            this.imageList1.Images.SetKeyName(4, "InvertHour");
            this.imageList1.Images.SetKeyName(5, "HourWise");
            this.imageList1.Images.SetKeyName(6, "vs");
            // 
            // picPassThrowMode
            // 
            this.picPassThrowMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.picPassThrowMode.ImageKey = "CannotPassThrow";
            this.picPassThrowMode.ImageList = this.imageList1;
            this.picPassThrowMode.Location = new System.Drawing.Point(302, 297);
            this.picPassThrowMode.Name = "picPassThrowMode";
            this.picPassThrowMode.Size = new System.Drawing.Size(51, 51);
            this.picPassThrowMode.TabIndex = 40;
            this.picPassThrowMode.TabStop = false;
            this.picPassThrowMode.UseVisualStyleBackColor = false;
            // 
            // picDropDownMode
            // 
            this.picDropDownMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.picDropDownMode.ImageKey = "CommonDrop";
            this.picDropDownMode.ImageList = this.imageList1;
            this.picDropDownMode.Location = new System.Drawing.Point(358, 297);
            this.picDropDownMode.Name = "picDropDownMode";
            this.picDropDownMode.Size = new System.Drawing.Size(51, 51);
            this.picDropDownMode.TabIndex = 41;
            this.picDropDownMode.TabStop = false;
            this.picDropDownMode.UseVisualStyleBackColor = false;
            this.picDropDownMode.Click += new System.EventHandler(this.picDropDownMode_Click);
            // 
            // picDropDownMode2
            // 
            this.picDropDownMode2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.picDropDownMode2.ImageKey = "CommonDrop";
            this.picDropDownMode2.ImageList = this.imageList1;
            this.picDropDownMode2.Location = new System.Drawing.Point(594, 295);
            this.picDropDownMode2.Name = "picDropDownMode2";
            this.picDropDownMode2.Size = new System.Drawing.Size(51, 51);
            this.picDropDownMode2.TabIndex = 43;
            this.picDropDownMode2.TabStop = false;
            this.picDropDownMode2.UseVisualStyleBackColor = false;
            this.picDropDownMode2.Click += new System.EventHandler(this.picDropDownMode2_Click);
            // 
            // picPassThrowMode2
            // 
            this.picPassThrowMode2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.picPassThrowMode2.ImageKey = "CannotPassThrow";
            this.picPassThrowMode2.ImageList = this.imageList1;
            this.picPassThrowMode2.Location = new System.Drawing.Point(538, 295);
            this.picPassThrowMode2.Name = "picPassThrowMode2";
            this.picPassThrowMode2.Size = new System.Drawing.Size(51, 51);
            this.picPassThrowMode2.TabIndex = 42;
            this.picPassThrowMode2.TabStop = false;
            this.picPassThrowMode2.UseVisualStyleBackColor = false;
            // 
            // btnPlay1Dirctor
            // 
            this.btnPlay1Dirctor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlay1Dirctor.ImageKey = "HourWise";
            this.btnPlay1Dirctor.ImageList = this.imageList1;
            this.btnPlay1Dirctor.Location = new System.Drawing.Point(302, 489);
            this.btnPlay1Dirctor.Name = "btnPlay1Dirctor";
            this.btnPlay1Dirctor.Size = new System.Drawing.Size(51, 51);
            this.btnPlay1Dirctor.TabIndex = 44;
            this.btnPlay1Dirctor.TabStop = false;
            this.btnPlay1Dirctor.UseVisualStyleBackColor = false;
            this.btnPlay1Dirctor.Click += new System.EventHandler(this.btnLeftCircle_Click);
            // 
            // btnPlay2Dirctor
            // 
            this.btnPlay2Dirctor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlay2Dirctor.ImageKey = "HourWise";
            this.btnPlay2Dirctor.ImageList = this.imageList1;
            this.btnPlay2Dirctor.Location = new System.Drawing.Point(594, 489);
            this.btnPlay2Dirctor.Name = "btnPlay2Dirctor";
            this.btnPlay2Dirctor.Size = new System.Drawing.Size(51, 51);
            this.btnPlay2Dirctor.TabIndex = 45;
            this.btnPlay2Dirctor.TabStop = false;
            this.btnPlay2Dirctor.UseVisualStyleBackColor = false;
            this.btnPlay2Dirctor.Click += new System.EventHandler(this.btnRightCircle_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(472, 553);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 59);
            this.label4.TabIndex = 47;
            this.label4.Text = "Player2:\r\n↑:变化 Del:攻击\r\n←:左 ↓:下 →:右\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(302, 553);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 59);
            this.label3.TabIndex = 48;
            this.label3.Text = "Player1:\r\nW:变化E:攻击\r\nA:左 S:下 D:右\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(302, 620);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(239, 16);
            this.label5.TabIndex = 49;
            this.label5.Text = "单人模式下,两种按键均有效!!";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(297, 385);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 50;
            this.label7.Text = "可攻击行数";
            // 
            // labFight1
            // 
            this.labFight1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labFight1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labFight1.Location = new System.Drawing.Point(387, 380);
            this.labFight1.Name = "labFight1";
            this.labFight1.Size = new System.Drawing.Size(41, 22);
            this.labFight1.TabIndex = 51;
            this.labFight1.Text = "0";
            this.labFight1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labFight2
            // 
            this.labFight2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labFight2.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labFight2.Location = new System.Drawing.Point(523, 380);
            this.labFight2.Name = "labFight2";
            this.labFight2.Size = new System.Drawing.Size(41, 22);
            this.labFight2.TabIndex = 53;
            this.labFight2.Text = "0";
            this.labFight2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(570, 385);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 52;
            this.label10.Text = "可攻击行数";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ImageKey = "vs";
            this.button1.ImageList = this.imageList1;
            this.button1.Location = new System.Drawing.Point(447, 366);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(51, 51);
            this.button1.TabIndex = 54;
            this.button1.TabStop = false;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(299, 364);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(351, 65);
            this.label11.TabIndex = 55;
            // 
            // GameViewer
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(946, 656);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labFight2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labFight1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnPlay2Dirctor);
            this.Controls.Add(this.btnPlay1Dirctor);
            this.Controls.Add(this.picDropDownMode2);
            this.Controls.Add(this.picPassThrowMode2);
            this.Controls.Add(this.picDropDownMode);
            this.Controls.Add(this.picPassThrowMode);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.labScore2);
            this.Controls.Add(this.labLevel2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.theNextSets2);
            this.Controls.Add(this.theGamePanel2);
            this.Controls.Add(this.labMaxScore);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labScore);
            this.Controls.Add(this.labClearLines2);
            this.Controls.Add(this.labClearLines);
            this.Controls.Add(this.labLevel);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.theNextSets1);
            this.Controls.Add(this.theGamePanel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "GameViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ZierbenTetris";
            this.Load += new System.EventHandler(this.GameViewer_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameViewer_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.theGamePanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.theNextSets1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.theNextSets2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.theGamePanel2)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox theGamePanel1;
        private System.Windows.Forms.PictureBox theNextSets1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labLevel;
        private System.Windows.Forms.Label labScore;
        private System.Windows.Forms.Label labMaxScore;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox theNextSets2;
        private System.Windows.Forms.PictureBox theGamePanel2;
        private System.Windows.Forms.Label labScore2;
        private System.Windows.Forms.Label labLevel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem 单人游戏F2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fightWithComputer;
        private System.Windows.Forms.ToolStripMenuItem 双人对战ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem 练习01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 练习02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem 闯关01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 闯关02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labClearLines;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labClearLines2;
        private System.Windows.Forms.ToolStripMenuItem 使用扩展方块ToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton4;
        private System.Windows.Forms.ToolStripMenuItem 背景音乐ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 音效ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem 图片设置ToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button picPassThrowMode;
        private System.Windows.Forms.Button picDropDownMode;
        private System.Windows.Forms.Button picDropDownMode2;
        private System.Windows.Forms.Button picPassThrowMode2;
        private System.Windows.Forms.Button btnPlay1Dirctor;
        private System.Windows.Forms.Button btnPlay2Dirctor;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripComboBox tsStartV;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripComboBox tsStartHardLevel;
        private System.Windows.Forms.ToolStripMenuItem 暂停游戏ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 终止对战ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labFight1;
        private System.Windows.Forms.Label labFight2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStripMenuItem 穿越模式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 电脑互相PKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 稍微难一点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 稍微容易一点的ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 小饼子ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmV1;
        private System.Windows.Forms.ToolStripMenuItem tsmV2;
        private System.Windows.Forms.ToolStripMenuItem tsmV3;
        private System.Windows.Forms.ToolStripMenuItem tsmV4;
        private System.Windows.Forms.ToolStripMenuItem tsmV5;
        private System.Windows.Forms.ToolStripMenuItem tsmV6;
        private System.Windows.Forms.ToolStripMenuItem tsmV7;
        private System.Windows.Forms.ToolStripMenuItem tsmV8;
        private System.Windows.Forms.ToolStripMenuItem tsmV9;
        private System.Windows.Forms.ToolStripMenuItem tsmV10;
        private System.Windows.Forms.ToolStripMenuItem tsmV0;
    }
}

